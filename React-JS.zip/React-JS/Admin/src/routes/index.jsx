import { lazy } from 'react';
import { Navigate } from 'react-router';
import MainLayout from '@/layouts/MainLayout';
export const routes = [{
  path: '',
  element: <Navigate to="/dashboard/ecommerce" />
}, {
  element: <MainLayout />,
  children: [{
  path: '/apps/api-keys',
  Component: lazy(() => import('@/views/admin/apps/api-keys'))
  }, {
  path: '/admin/sections',
  Component: lazy(() => import('@/views/admin/apps/sections/SectionList'))
  }, {
  path: '/admin/sections/create',
  Component: lazy(() => import('@/views/admin/apps/sections/SectionCreate'))
  }, {
  path: '/admin/sections/:id/edit',
  Component: lazy(() => import('@/views/admin/apps/sections/SectionEdit'))
  }, {
    path: '/apps/blog/add',
    Component: lazy(() => import('@/views/admin/apps/blog/add'))
  }, {
    path: '/apps/blog/article',
    Component: lazy(() => import('@/views/admin/apps/blog/article'))
  }, {
    path: '/apps/blog/grid',
    Component: lazy(() => import('@/views/admin/apps/blog/grid'))
  }, {
    path: '/apps/blog/list',
    Component: lazy(() => import('@/views/admin/apps/blog/list'))
  }, {
    path: '/apps/calendar',
    Component: lazy(() => import('@/views/admin/apps/calendar'))
  }, {
    path: '/apps/chat',
    Component: lazy(() => import('@/views/admin/apps/chat'))
  }, {
    path: '/apps/clients',
    Component: lazy(() => import('@/views/admin/apps/clients'))
  }, {
    path: '/apps/companies',
    Component: lazy(() => import('@/views/admin/apps/companies'))
  }, {
    path: '/apps/crm/activities',
    Component: lazy(() => import('@/views/admin/apps/crm/activities'))
  }, {
    path: '/apps/crm/campaign',
    Component: lazy(() => import('@/views/admin/apps/crm/campaign'))
  }, {
    path: '/apps/crm/contacts',
    Component: lazy(() => import('@/views/admin/apps/crm/contacts'))
  }, {
    path: '/apps/crm/customers',
    Component: lazy(() => import('@/views/admin/apps/crm/customers'))
  }, {
    path: '/apps/crm/deals',
    Component: lazy(() => import('@/views/admin/apps/crm/deals'))
  }, {
    path: '/apps/crm/estimations',
    Component: lazy(() => import('@/views/admin/apps/crm/estimations'))
  }, {
    path: '/apps/crm/leads',
    Component: lazy(() => import('@/views/admin/apps/crm/leads'))
  }, {
    path: '/apps/crm/opportunities',
    Component: lazy(() => import('@/views/admin/apps/crm/opportunities'))
  }, {
    path: '/apps/crm/pipeline',
    Component: lazy(() => import('@/views/admin/apps/crm/pipeline'))
  }, {
    path: '/apps/crm/proposals',
    Component: lazy(() => import('@/views/admin/apps/crm/proposals'))
  }, {
    path: '/apps/ecommerce/attributes',
    Component: lazy(() => import('@/views/admin/apps/ecommerce/attributes'))
  }, {
    path: '/apps/ecommerce/cart',
    Component: lazy(() => import('@/views/admin/apps/ecommerce/cart'))
  }, {
    path: '/apps/ecommerce/categories',
    Component: lazy(() => import('@/views/admin/apps/ecommerce/categories'))
  }, {
    path: '/apps/ecommerce/checkout',
    Component: lazy(() => import('@/views/admin/apps/ecommerce/checkout'))
  }, {
    path: '/apps/ecommerce/customers',
    Component: lazy(() => import('@/views/admin/apps/ecommerce/customers'))
  }, {
    path: '/apps/ecommerce/order-add',
    Component: lazy(() => import('@/views/admin/apps/ecommerce/orders/order-add'))
  }, {
    path: '/apps/ecommerce/order-details',
    Component: lazy(() => import('@/views/admin/apps/ecommerce/orders/order-details'))
  }, {
    path: '/apps/ecommerce/orders',
    Component: lazy(() => import('@/views/admin/apps/ecommerce/orders/orders'))
  }, {
    path: '/apps/ecommerce/product-add',
    Component: lazy(() => import('@/views/admin/apps/ecommerce/products/product-add'))
  }, {
    path: '/apps/ecommerce/product-details',
    Component: lazy(() => import('@/views/admin/apps/ecommerce/products/product-details'))
  }, {
    path: '/apps/ecommerce/product-stocks',
    Component: lazy(() => import('@/views/admin/apps/ecommerce/inventory/product-stocks'))
  }, {
    path: '/apps/ecommerce/product-views',
    Component: lazy(() => import('@/views/admin/apps/ecommerce/reports/product-views'))
  }, {
    path: '/apps/ecommerce/products',
    Component: lazy(() => import('@/views/admin/apps/ecommerce/products/products'))
  }, {
    path: '/apps/ecommerce/products-grid',
    Component: lazy(() => import('@/views/admin/apps/ecommerce/products/products-grid'))
  }, {
    path: '/apps/ecommerce/purchased-orders',
    Component: lazy(() => import('@/views/admin/apps/ecommerce/inventory/purchased-orders'))
  }, {
    path: '/apps/ecommerce/refunds',
    Component: lazy(() => import('@/views/admin/apps/ecommerce/refunds'))
  }, {
    path: '/apps/ecommerce/reviews',
    Component: lazy(() => import('@/views/admin/apps/ecommerce/reviews'))
  }, {
    path: '/apps/ecommerce/sales',
    Component: lazy(() => import('@/views/admin/apps/ecommerce/reports/sales'))
  }, {
    path: '/apps/ecommerce/seller-details',
    Component: lazy(() => import('@/views/admin/apps/ecommerce/sellers/seller-details'))
  }, {
    path: '/apps/ecommerce/sellers',
    Component: lazy(() => import('@/views/admin/apps/ecommerce/sellers/sellers'))
  }, {
    path: '/apps/ecommerce/settings',
    Component: lazy(() => import('@/views/admin/apps/ecommerce/settings'))
  }, {
    path: '/apps/ecommerce/warehouse',
    Component: lazy(() => import('@/views/admin/apps/ecommerce/inventory/warehouse'))
  }, {
    path: '/apps/email/compose',
    Component: lazy(() => import('@/views/admin/apps/email/compose'))
  }, {
    path: '/apps/email/details',
    Component: lazy(() => import('@/views/admin/apps/email/details'))
  }, {
    path: '/apps/email/inbox',
    Component: lazy(() => import('@/views/admin/apps/email/inbox'))
  }, {
    path: '/apps/file-manager',
    Component: lazy(() => import('@/views/admin/apps/file-manager'))
  }, {
    path: '/apps/finance/banks-cards',
    Component: lazy(() => import('@/views/admin/apps/finance/banks-cards'))
  }, {
    path: '/apps/finance/expense-category',
    Component: lazy(() => import('@/views/admin/apps/finance/expense-category'))
  }, {
    path: '/apps/finance/expenses',
    Component: lazy(() => import('@/views/admin/apps/finance/expenses'))
  }, {
    path: '/apps/finance/income',
    Component: lazy(() => import('@/views/admin/apps/finance/income'))
  }, {
    path: '/apps/finance/transactions',
    Component: lazy(() => import('@/views/admin/apps/finance/transactions'))
  }, {
    path: '/apps/forum/post',
    Component: lazy(() => import('@/views/admin/apps/forum/post'))
  }, {
    path: '/apps/forum/view',
    Component: lazy(() => import('@/views/admin/apps/forum/view'))
  }, {
    path: '/apps/hrm/attendance',
    Component: lazy(() => import('@/views/admin/apps/hrm/attendance'))
  }, {
    path: '/apps/hrm/create-salary-slip',
    Component: lazy(() => import('@/views/admin/apps/hrm/create-salary-slip'))
  }, {
    path: '/apps/hrm/departments',
    Component: lazy(() => import('@/views/admin/apps/hrm/departments'))
  }, {
    path: '/apps/hrm/holidays',
    Component: lazy(() => import('@/views/admin/apps/hrm/holidays'))
  }, {
    path: '/apps/hrm/leave-add',
    Component: lazy(() => import('@/views/admin/apps/hrm/leave-add'))
  }, {
    path: '/apps/hrm/leaves',
    Component: lazy(() => import('@/views/admin/apps/hrm/leaves'))
  }, {
    path: '/apps/hrm/payroll',
    Component: lazy(() => import('@/views/admin/apps/hrm/payroll'))
  }, {
    path: '/apps/hrm/staff-add',
    Component: lazy(() => import('@/views/admin/apps/hrm/staff-add'))
  }, {
    path: '/apps/hrm/staff-profile',
    Component: lazy(() => import('@/views/admin/apps/hrm/staff-profile'))
  }, {
    path: '/apps/hrm/staffs',
    Component: lazy(() => import('@/views/admin/apps/hrm/staffs'))
  }, {
    path: '/apps/invoice/create',
    Component: lazy(() => import('@/views/admin/apps/invoice/create'))
  }, {
    path: '/apps/invoice/details',
    Component: lazy(() => import('@/views/admin/apps/invoice/details'))
  }, {
    path: '/apps/invoice/list',
    Component: lazy(() => import('@/views/admin/apps/invoice/list'))
  }, {
    path: '/apps/issue-tracker',
    Component: lazy(() => import('@/views/admin/apps/issue-tracker'))
  }, {
    path: '/apps/manage',
    Component: lazy(() => import('@/views/admin/apps/manage'))
  }, {
    path: '/apps/outlook',
    Component: lazy(() => import('@/views/admin/apps/outlook'))
  }, {
    path: '/apps/pin-board',
    Component: lazy(() => import('@/views/admin/apps/pin-board'))
  }, {
    path: '/apps/pro-ai',
    Component: lazy(() => import('@/views/admin/apps/pro-ai'))
  }, {
    path: '/apps/projects/activity',
    Component: lazy(() => import('@/views/admin/apps/projects/activity'))
  }, {
    path: '/apps/projects/details',
    Component: lazy(() => import('@/views/admin/apps/projects/details'))
  }, {
    path: '/apps/projects/grid',
    Component: lazy(() => import('@/views/admin/apps/projects/grid'))
  }, {
    path: '/apps/projects/kanban',
    Component: lazy(() => import('@/views/admin/apps/projects/kanban'))
  }, {
    path: '/apps/projects/list',
    Component: lazy(() => import('@/views/admin/apps/projects/list'))
  }, {
    path: '/apps/projects/team-board',
    Component: lazy(() => import('@/views/admin/apps/projects/team-board'))
  }, {
    path: '/apps/promo/coupons',
    Component: lazy(() => import('@/views/admin/apps/promo/coupons'))
  }, {
    path: '/apps/promo/discounts',
    Component: lazy(() => import('@/views/admin/apps/promo/discounts'))
  }, {
    path: '/apps/promo/gift-cards',
    Component: lazy(() => import('@/views/admin/apps/promo/gift-cards'))
  }, {
    path: '/apps/social-feed',
    Component: lazy(() => import('@/views/admin/apps/social-feed'))
  }, {
    path: '/apps/task/create',
    Component: lazy(() => import('@/views/admin/apps/task/create'))
  }, {
    path: '/apps/task/details',
    Component: lazy(() => import('@/views/admin/apps/task/details'))
  }, {
    path: '/apps/task/list',
    Component: lazy(() => import('@/views/admin/apps/task/list'))
  }, {
    path: '/apps/ticket/create',
    Component: lazy(() => import('@/views/admin/apps/ticket/create'))
  }, {
    path: '/apps/ticket/details',
    Component: lazy(() => import('@/views/admin/apps/ticket/details'))
  }, {
    path: '/apps/ticket/list',
    Component: lazy(() => import('@/views/admin/apps/ticket/list'))
  }, {
    path: '/apps/todo',
    Component: lazy(() => import('@/views/admin/apps/todo'))
  }, {
    path: '/apps/users/account-settings',
    Component: lazy(() => import('@/views/admin/apps/users/account-settings'))
  }, {
    path: '/apps/users/contacts',
    Component: lazy(() => import('@/views/admin/apps/users/contacts'))
  }, {
    path: '/apps/users/permissions',
    Component: lazy(() => import('@/views/admin/apps/users/permissions'))
  }, {
    path: '/apps/users/profile',
    Component: lazy(() => import('@/views/admin/apps/users/profile'))
  }, {
    path: '/apps/users/role-details',
    Component: lazy(() => import('@/views/admin/apps/users/role-details'))
  }, {
    path: '/apps/users/roles',
    Component: lazy(() => import('@/views/admin/apps/users/roles'))
  }, {
    path: '/apps/vote-list',
    Component: lazy(() => import('@/views/admin/apps/vote-list'))
  }, {
    path: '/charts/apex/area',
    Component: lazy(() => import('@/views/admin/charts/apex/area'))
  }, {
    path: '/charts/apex/bar',
    Component: lazy(() => import('@/views/admin/charts/apex/bar'))
  }, {
    path: '/charts/apex/boxplot',
    Component: lazy(() => import('@/views/admin/charts/apex/boxplot'))
  }, {
    path: '/charts/apex/bubble',
    Component: lazy(() => import('@/views/admin/charts/apex/bubble'))
  }, {
    path: '/charts/apex/candlestick',
    Component: lazy(() => import('@/views/admin/charts/apex/candlestick'))
  }, {
    path: '/charts/apex/column',
    Component: lazy(() => import('@/views/admin/charts/apex/column'))
  }, {
    path: '/charts/apex/funnel',
    Component: lazy(() => import('@/views/admin/charts/apex/funnel'))
  }, {
    path: '/charts/apex/heatmap',
    Component: lazy(() => import('@/views/admin/charts/apex/heatmap'))
  }, {
    path: '/charts/apex/line',
    Component: lazy(() => import('@/views/admin/charts/apex/line'))
  }, {
    path: '/charts/apex/mixed',
    Component: lazy(() => import('@/views/admin/charts/apex/mixed'))
  }, {
    path: '/charts/apex/pie',
    Component: lazy(() => import('@/views/admin/charts/apex/pie'))
  }, {
    path: '/charts/apex/polar-area',
    Component: lazy(() => import('@/views/admin/charts/apex/polar-area'))
  }, {
    path: '/charts/apex/radar',
    Component: lazy(() => import('@/views/admin/charts/apex/radar'))
  }, {
    path: '/charts/apex/radialbar',
    Component: lazy(() => import('@/views/admin/charts/apex/radialbar'))
  }, {
    path: '/charts/apex/range',
    Component: lazy(() => import('@/views/admin/charts/apex/range'))
  }, {
    path: '/charts/apex/scatter',
    Component: lazy(() => import('@/views/admin/charts/apex/scatter'))
  }, {
    path: '/charts/apex/slope',
    Component: lazy(() => import('@/views/admin/charts/apex/slope'))
  }, {
    path: '/charts/apex/sparklines',
    Component: lazy(() => import('@/views/admin/charts/apex/sparklines'))
  }, {
    path: '/charts/apex/timeline',
    Component: lazy(() => import('@/views/admin/charts/apex/timeline'))
  }, {
    path: '/charts/apex/treemap',
    Component: lazy(() => import('@/views/admin/charts/apex/treemap'))
  }, {
    path: '/charts/chartjs/area',
    Component: lazy(() => import('@/views/admin/charts/chartjs/area'))
  }, {
    path: '/charts/chartjs/bar',
    Component: lazy(() => import('@/views/admin/charts/chartjs/bar'))
  }, {
    path: '/charts/chartjs/line',
    Component: lazy(() => import('@/views/admin/charts/chartjs/line'))
  }, {
    path: '/charts/chartjs/other',
    Component: lazy(() => import('@/views/admin/charts/chartjs/other'))
  }, {
    path: '/charts/echart/area',
    Component: lazy(() => import('@/views/admin/charts/echart/area'))
  }, {
    path: '/charts/echart/bar',
    Component: lazy(() => import('@/views/admin/charts/echart/bar'))
  }, {
    path: '/charts/echart/candlestick',
    Component: lazy(() => import('@/views/admin/charts/echart/candlestick'))
  }, {
    path: '/charts/echart/gauge',
    Component: lazy(() => import('@/views/admin/charts/echart/gauge'))
  }, {
    path: '/charts/echart/geo-map',
    Component: lazy(() => import('@/views/admin/charts/echart/geo-map'))
  }, {
    path: '/charts/echart/heatmap',
    Component: lazy(() => import('@/views/admin/charts/echart/heatmap'))
  }, {
    path: '/charts/echart/line',
    Component: lazy(() => import('@/views/admin/charts/echart/line'))
  }, {
    path: '/charts/echart/other',
    Component: lazy(() => import('@/views/admin/charts/echart/other'))
  }, {
    path: '/charts/echart/pie',
    Component: lazy(() => import('@/views/admin/charts/echart/pie'))
  }, {
    path: '/charts/echart/radar',
    Component: lazy(() => import('@/views/admin/charts/echart/radar'))
  }, {
    path: '/charts/echart/scatter',
    Component: lazy(() => import('@/views/admin/charts/echart/scatter'))
  }, {
    path: '/dashboard/analytics',
    Component: lazy(() => import('@/views/admin/dashboard/analytics'))
  }, {
    path: '/dashboard/crm',
    Component: lazy(() => import('@/views/admin/dashboard/crm'))
  }, {
    path: '/dashboard/ecommerce',
    Component: lazy(() => import('@/views/admin/dashboard/ecommerce'))
  }, {
    path: '/dashboard/finance',
    Component: lazy(() => import('@/views/admin/dashboard/finance'))
  }, {
    path: '/dashboard/projects',
    Component: lazy(() => import('@/views/admin/dashboard/projects'))
  }, {
    path: '/form/cropper',
    Component: lazy(() => import('@/views/admin/form/cropper'))
  }, {
    path: '/form/elements',
    Component: lazy(() => import('@/views/admin/form/elements'))
  }, {
    path: '/form/fileuploads',
    Component: lazy(() => import('@/views/admin/form/fileuploads'))
  }, {
    path: '/form/layout',
    Component: lazy(() => import('@/views/admin/form/layout'))
  }, {
    path: '/form/other-plugin',
    Component: lazy(() => import('@/views/admin/form/other-plugin'))
  }, {
    path: '/form/pickers',
    Component: lazy(() => import('@/views/admin/form/pickers'))
  }, {
    path: '/form/range-slider',
    Component: lazy(() => import('@/views/admin/form/range-slider'))
  }, {
    path: '/form/select',
    Component: lazy(() => import('@/views/admin/form/select'))
  }, {
    path: '/form/text-editors',
    Component: lazy(() => import('@/views/admin/form/text-editors'))
  }, {
    path: '/form/validation',
    Component: lazy(() => import('@/views/admin/form/validation'))
  }, {
    path: '/form/wizard',
    Component: lazy(() => import('@/views/admin/form/wizard'))
  }, {
    path: '/icons/boxicons',
    Component: lazy(() => import('@/views/admin/icons/boxicons'))
  }, {
    path: '/icons/flags',
    Component: lazy(() => import('@/views/admin/icons/flags'))
  }, {
    path: '/icons/lucide',
    Component: lazy(() => import('@/views/admin/icons/lucide'))
  }, {
    path: '/icons/remix',
    Component: lazy(() => import('@/views/admin/icons/remix'))
  }, {
    path: '/icons/solar-broken',
    Component: lazy(() => import('@/views/admin/icons/solar-broken'))
  }, {
    path: '/icons/solar-duotone',
    Component: lazy(() => import('@/views/admin/icons/solar-duotone'))
  }, {
    path: '/icons/tabler',
    Component: lazy(() => import('@/views/admin/icons/tabler'))
  }, {
    path: '/layouts/boxed',
    Component: lazy(() => import('@/views/admin/layouts/boxed'))
  }, {
    path: '/layouts/compact',
    Component: lazy(() => import('@/views/admin/layouts/compact'))
  }, {
    path: '/layouts/horizontal',
    Component: lazy(() => import('@/views/admin/layouts/horizontal'))
  }, {
    path: '/layouts/preloader',
    Component: lazy(() => import('@/views/admin/layouts/preloader'))
  }, {
    path: '/layouts/scrollable',
    Component: lazy(() => import('@/views/admin/layouts/scrollable'))
  }, {
    path: '/layouts/sidebar-compact',
    Component: lazy(() => import('@/views/admin/layouts/sidebar-compact'))
  }, {
    path: '/layouts/sidebar-gradient',
    Component: lazy(() => import('@/views/admin/layouts/sidebar-gradient'))
  }, {
    path: '/layouts/sidebar-gray',
    Component: lazy(() => import('@/views/admin/layouts/sidebar-gray'))
  }, {
    path: '/layouts/sidebar-image',
    Component: lazy(() => import('@/views/admin/layouts/sidebar-image'))
  }, {
    path: '/layouts/sidebar-light',
    Component: lazy(() => import('@/views/admin/layouts/sidebar-light'))
  }, {
    path: '/layouts/sidebar-no-icons',
    Component: lazy(() => import('@/views/admin/layouts/sidebar-no-icons'))
  }, {
    path: '/layouts/sidebar-offcanvas',
    Component: lazy(() => import('@/views/admin/layouts/sidebar-offcanvas'))
  }, {
    path: '/layouts/sidebar-on-hover',
    Component: lazy(() => import('@/views/admin/layouts/sidebar-on-hover'))
  }, {
    path: '/layouts/sidebar-with-lines',
    Component: lazy(() => import('@/views/admin/layouts/sidebar-with-lines'))
  }, {
    path: '/layouts/topbar-dark',
    Component: lazy(() => import('@/views/admin/layouts/topbar-dark'))
  }, {
    path: '/layouts/topbar-gradient',
    Component: lazy(() => import('@/views/admin/layouts/topbar-gradient'))
  }, {
    path: '/layouts/topbar-gray',
    Component: lazy(() => import('@/views/admin/layouts/topbar-gray'))
  }, {
    path: '/maps/google',
    Component: lazy(() => import('@/views/admin/maps/google'))
  }, {
    path: '/maps/leaflet',
    Component: lazy(() => import('@/views/admin/maps/leaflet'))
  }, {
    path: '/maps/vector',
    Component: lazy(() => import('@/views/admin/maps/vector'))
  }, {
    path: '/pages/about-us',
    Component: lazy(() => import('@/views/admin/pages/about-us'))
  }, {
    path: '/pages/contact-us',
    Component: lazy(() => import('@/views/admin/pages/contact-us'))
  }, {
    path: '/pages/empty',
    Component: lazy(() => import('@/views/admin/pages/empty'))
  }, {
    path: '/pages/faq',
    Component: lazy(() => import('@/views/admin/pages/faq'))
  }, {
    path: '/pages/gallery',
    Component: lazy(() => import('@/views/admin/pages/gallery'))
  }, {
    path: '/pages/pricing',
    Component: lazy(() => import('@/views/admin/pages/pricing'))
  }, {
    path: '/pages/privacy-policy',
    Component: lazy(() => import('@/views/admin/pages/privacy-policy'))
  }, {
    path: '/pages/search-results',
    Component: lazy(() => import('@/views/admin/pages/search-results'))
  }, {
    path: '/pages/sitemap',
    Component: lazy(() => import('@/views/admin/pages/sitemap'))
  }, {
    path: '/pages/terms-conditions',
    Component: lazy(() => import('@/views/admin/pages/terms-conditions'))
  }, {
    path: '/pages/timeline',
    Component: lazy(() => import('@/views/admin/pages/timeline'))
  }, {
    path: '/plugins/animation',
    Component: lazy(() => import('@/views/admin/plugins/animation'))
  }, {
    path: '/plugins/clipboard',
    Component: lazy(() => import('@/views/admin/plugins/clipboard'))
  }, {
    path: '/plugins/idle-timer',
    Component: lazy(() => import('@/views/admin/plugins/idle-timer'))
  }, {
    path: '/plugins/masonry',
    Component: lazy(() => import('@/views/admin/plugins/masonry'))
  }, {
    path: '/plugins/pass-meter',
    Component: lazy(() => import('@/views/admin/plugins/pass-meter'))
  }, {
    path: '/plugins/pdf-viewer',
    Component: lazy(() => import('@/views/admin/plugins/pdf-viewer'))
  }, {
    path: '/plugins/sweet-alerts',
    Component: lazy(() => import('@/views/admin/plugins/sweet-alerts'))
  }, {
    path: '/plugins/tour',
    Component: lazy(() => import('@/views/admin/plugins/tour'))
  }, {
    path: '/plugins/tree-view',
    Component: lazy(() => import('@/views/admin/plugins/tree-view'))
  }, {
    path: '/plugins/video-player',
    Component: lazy(() => import('@/views/admin/plugins/video-player'))
  }, {
    path: '/tables/custom',
    Component: lazy(() => import('@/views/admin/tables/custom'))
  }, {
    path: '/tables/datatables/ajax',
    Component: lazy(() => import('@/views/admin/tables/datatables/ajax'))
  }, {
    path: '/tables/datatables/basic',
    Component: lazy(() => import('@/views/admin/tables/datatables/basic'))
  }, {
    path: '/tables/datatables/checkbox-select',
    Component: lazy(() => import('@/views/admin/tables/datatables/checkbox-select'))
  }, {
    path: '/tables/datatables/child-rows',
    Component: lazy(() => import('@/views/admin/tables/datatables/child-rows'))
  }, {
    path: '/tables/datatables/column-searching',
    Component: lazy(() => import('@/views/admin/tables/datatables/column-searching'))
  }, {
    path: '/tables/datatables/columns',
    Component: lazy(() => import('@/views/admin/tables/datatables/columns'))
  }, {
    path: '/tables/datatables/export-data',
    Component: lazy(() => import('@/views/admin/tables/datatables/export-data'))
  }, {
    path: '/tables/datatables/fixed-columns',
    Component: lazy(() => import('@/views/admin/tables/datatables/fixed-columns'))
  }, {
    path: '/tables/datatables/fixed-header',
    Component: lazy(() => import('@/views/admin/tables/datatables/fixed-header'))
  }, {
    path: '/tables/datatables/javascript',
    Component: lazy(() => import('@/views/admin/tables/datatables/javascript'))
  }, {
    path: '/tables/datatables/range-search',
    Component: lazy(() => import('@/views/admin/tables/datatables/range-search'))
  }, {
    path: '/tables/datatables/rendering',
    Component: lazy(() => import('@/views/admin/tables/datatables/rendering'))
  }, {
    path: '/tables/datatables/rows-add',
    Component: lazy(() => import('@/views/admin/tables/datatables/rows-add'))
  }, {
    path: '/tables/datatables/scroll',
    Component: lazy(() => import('@/views/admin/tables/datatables/scroll'))
  }, {
    path: '/tables/datatables/select',
    Component: lazy(() => import('@/views/admin/tables/datatables/select'))
  }, {
    path: '/tables/static',
    Component: lazy(() => import('@/views/admin/tables/static'))
  }, {
    path: '/ui/accordions',
    Component: lazy(() => import('@/views/admin/ui/accordions'))
  }, {
    path: '/ui/alerts',
    Component: lazy(() => import('@/views/admin/ui/alerts'))
  }, {
    path: '/ui/badges',
    Component: lazy(() => import('@/views/admin/ui/badges'))
  }, {
    path: '/ui/breadcrumb',
    Component: lazy(() => import('@/views/admin/ui/breadcrumb'))
  }, {
    path: '/ui/buttons',
    Component: lazy(() => import('@/views/admin/ui/buttons'))
  }, {
    path: '/ui/cards',
    Component: lazy(() => import('@/views/admin/ui/cards'))
  }, {
    path: '/ui/carousel',
    Component: lazy(() => import('@/views/admin/ui/carousel'))
  }, {
    path: '/ui/collapse',
    Component: lazy(() => import('@/views/admin/ui/collapse'))
  }, {
    path: '/ui/colors',
    Component: lazy(() => import('@/views/admin/ui/colors'))
  }, {
    path: '/ui/dropdowns',
    Component: lazy(() => import('@/views/admin/ui/dropdowns'))
  }, {
    path: '/ui/grid',
    Component: lazy(() => import('@/views/admin/ui/grid'))
  }, {
    path: '/ui/images',
    Component: lazy(() => import('@/views/admin/ui/images'))
  }, {
    path: '/ui/links',
    Component: lazy(() => import('@/views/admin/ui/links'))
  }, {
    path: '/ui/list-group',
    Component: lazy(() => import('@/views/admin/ui/list-group'))
  }, {
    path: '/ui/modals',
    Component: lazy(() => import('@/views/admin/ui/modals'))
  }, {
    path: '/ui/notifications',
    Component: lazy(() => import('@/views/admin/ui/notifications'))
  }, {
    path: '/ui/offcanvas',
    Component: lazy(() => import('@/views/admin/ui/offcanvas'))
  }, {
    path: '/ui/pagination',
    Component: lazy(() => import('@/views/admin/ui/pagination'))
  }, {
    path: '/ui/placeholders',
    Component: lazy(() => import('@/views/admin/ui/placeholders'))
  }, {
    path: '/ui/popovers',
    Component: lazy(() => import('@/views/admin/ui/popovers'))
  }, {
    path: '/ui/progress',
    Component: lazy(() => import('@/views/admin/ui/progress'))
  }, {
    path: '/ui/spinners',
    Component: lazy(() => import('@/views/admin/ui/spinners'))
  }, {
    path: '/ui/tabs',
    Component: lazy(() => import('@/views/admin/ui/tabs'))
  }, {
    path: '/ui/tooltips',
    Component: lazy(() => import('@/views/admin/ui/tooltips'))
  }, {
    path: '/ui/typography',
    Component: lazy(() => import('@/views/admin/ui/typography'))
  }, {
    path: '/ui/utilities',
    Component: lazy(() => import('@/views/admin/ui/utilities'))
  }, {
    path: '/ui/videos',
    Component: lazy(() => import('@/views/admin/ui/videos'))
  }, {
    path: '/widgets/charts',
    Component: lazy(() => import('@/views/admin/widgets/charts'))
  }, {
    path: '/widgets/mixed',
    Component: lazy(() => import('@/views/admin/widgets/mixed'))
  }, {
    path: '/widgets/social',
    Component: lazy(() => import('@/views/admin/widgets/social'))
  }, {
    path: '/widgets/statistics',
    Component: lazy(() => import('@/views/admin/widgets/statistics'))
  }, {
    path: '/widgets/weather',
    Component: lazy(() => import('@/views/admin/widgets/weather'))
  }]
}, {
  path: '/auth/card/delete-account',
  Component: lazy(() => import('@/views/auth/card/delete-account'))
}, {
  path: '/auth/card/lock-screen',
  Component: lazy(() => import('@/views/auth/card/lock-screen'))
}, {
  path: '/auth/card/login-pin',
  Component: lazy(() => import('@/views/auth/card/login-pin'))
}, {
  path: '/auth/card/new-pass',
  Component: lazy(() => import('@/views/auth/card/new-pass'))
}, {
  path: '/auth/card/reset-pass',
  Component: lazy(() => import('@/views/auth/card/reset-pass'))
}, {
  path: '/auth/card/sign-in',
  Component: lazy(() => import('@/views/auth/card/sign-in'))
}, {
  path: '/auth/card/sign-up',
  Component: lazy(() => import('@/views/auth/card/sign-up'))
}, {
  path: '/auth/card/success-mail',
  Component: lazy(() => import('@/views/auth/card/success-mail'))
}, {
  path: '/auth/card/two-factor',
  Component: lazy(() => import('@/views/auth/card/two-factor'))
}, {
  path: '/auth/delete-account',
  Component: lazy(() => import('@/views/auth/basic/delete-account'))
}, {
  path: '/auth/lock-screen',
  Component: lazy(() => import('@/views/auth/basic/lock-screen'))
}, {
  path: '/auth/login-pin',
  Component: lazy(() => import('@/views/auth/basic/login-pin'))
}, {
  path: '/auth/new-pass',
  Component: lazy(() => import('@/views/auth/basic/new-pass'))
}, {
  path: '/auth/reset-pass',
  Component: lazy(() => import('@/views/auth/basic/reset-pass'))
}, {
  path: '/auth/sign-in',
  Component: lazy(() => import('@/views/auth/basic/sign-in'))
}, {
  path: '/auth/sign-up',
  Component: lazy(() => import('@/views/auth/basic/sign-up'))
}, {
  path: '/auth/split/delete-account',
  Component: lazy(() => import('@/views/auth/split/delete-account'))
}, {
  path: '/auth/split/lock-screen',
  Component: lazy(() => import('@/views/auth/split/lock-screen'))
}, {
  path: '/auth/split/login-pin',
  Component: lazy(() => import('@/views/auth/split/login-pin'))
}, {
  path: '/auth/split/new-pass',
  Component: lazy(() => import('@/views/auth/split/new-pass'))
}, {
  path: '/auth/split/reset-pass',
  Component: lazy(() => import('@/views/auth/split/reset-pass'))
}, {
  path: '/auth/split/sign-in',
  Component: lazy(() => import('@/views/auth/split/sign-in'))
}, {
  path: '/auth/split/sign-up',
  Component: lazy(() => import('@/views/auth/split/sign-up'))
}, {
  path: '/auth/split/success-mail',
  Component: lazy(() => import('@/views/auth/split/success-mail'))
}, {
  path: '/auth/split/two-factor',
  Component: lazy(() => import('@/views/auth/split/two-factor'))
}, {
  path: '/auth/success-mail',
  Component: lazy(() => import('@/views/auth/basic/success-mail'))
}, {
  path: '/auth/two-factor',
  Component: lazy(() => import('@/views/auth/basic/two-factor'))
}, {
  path: '/error/400',
  Component: lazy(() => import('@/views/error/400'))
}, {
  path: '/error/401',
  Component: lazy(() => import('@/views/error/401'))
}, {
  path: '/error/403',
  Component: lazy(() => import('@/views/error/403'))
}, {
  path: '/error/404',
  Component: lazy(() => import('@/views/error/404'))
}, {
  path: '/error/408',
  Component: lazy(() => import('@/views/error/408'))
}, {
  path: '/error/500',
  Component: lazy(() => import('@/views/error/500'))
}, {
  path: '/error/maintenance',
  Component: lazy(() => import('@/views/error/maintenance'))
}, {
  path: '/pages/coming-soon',
  Component: lazy(() => import('@/views/others/pages/coming-soon'))
}];