import Icon from "@/components/wrappers/Icon";
import { useLayoutContext } from "@/context/useLayoutContext";
const CustomizerToggler = () => {
  const {
    toggleCustomizer
  } = useLayoutContext();
  return <div className="topbar-item d-none d-sm-flex btn-theme-setting">
      <button className="topbar-link" data-bs-toggle="offcanvas" data-bs-target="#theme-settings-offcanvas" type="button" onClick={toggleCustomizer}>
        <span className="topbar-link-icon">
          <span>
            <Icon icon="settings" />
          </span>
        </span>
      </button>
    </div>;
};
export default CustomizerToggler;