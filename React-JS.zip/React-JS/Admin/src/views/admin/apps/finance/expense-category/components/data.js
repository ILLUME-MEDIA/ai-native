export const categoryData = [{
  id: '#CAT-001',
  name: 'Office Supplies',
  expenses: '$2,845.60',
  status: 'active',
  date: '10 Oct, 2025',
  time: '04:10 PM'
}, {
  id: '#CAT-002',
  name: 'Travel',
  expenses: '$5,920.00',
  status: 'active',
  date: '08 Oct, 2025',
  time: '11:00 AM'
}, {
  id: '#CAT-003',
  name: 'Meals',
  expenses: '$1,280.75',
  status: 'active',
  date: '05 Oct, 2025',
  time: '07:45 PM'
}, {
  id: '#CAT-004',
  name: 'Entertainment',
  expenses: '$2,140.20',
  status: 'inactive',
  date: '03 Oct, 2025',
  time: '09:25 AM'
}, {
  id: '#CAT-005',
  name: 'Equipment',
  expenses: '$4,580.00',
  status: 'active',
  date: '01 Oct, 2025',
  time: '03:15 PM'
}, {
  id: '#CAT-006',
  name: 'Maintenance',
  expenses: '$3,210.40',
  status: 'active',
  date: '28 Sep, 2025',
  time: '02:00 PM'
}, {
  id: '#CAT-007',
  name: 'Training & Events',
  expenses: '$6,845.00',
  status: 'active',
  date: '25 Sep, 2025',
  time: '10:35 AM'
}, {
  id: '#CAT-008',
  name: 'Subscriptions',
  expenses: '$980.75',
  status: 'inactive',
  date: '21 Sep, 2025',
  time: '09:50 AM'
}, {
  id: '#CAT-009',
  name: 'Marketing',
  expenses: '$9,475.90',
  status: 'active',
  date: '18 Sep, 2025',
  time: '01:40 PM'
}, {
  id: '#CAT-010',
  name: 'Insurance',
  expenses: '$2,540.00',
  status: 'inactive',
  date: '15 Sep, 2025',
  time: '05:15 PM'
}];