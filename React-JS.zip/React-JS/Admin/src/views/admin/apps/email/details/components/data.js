export const toolbarButtonData = [{
  title: 'Bold',
  icon: 'bold'
}, {
  title: 'Italic',
  icon: 'italic'
}, {
  title: 'Attach files',
  icon: 'paperclip'
}, {
  title: 'Insert link',
  icon: 'link'
}, {
  title: 'Insert photo',
  icon: 'photo-up'
}];
export const emailActionData = [{
  icon: 'trash',
  label: 'Delete'
}, {
  icon: 'mail-opened',
  label: 'Mark as Read'
}, {
  icon: 'tag',
  label: 'Tag'
}, {
  icon: 'archive',
  label: 'Archive'
}];