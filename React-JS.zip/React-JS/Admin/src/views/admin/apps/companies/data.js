import airbnb from '@/assets/images/logos/airbnb.svg';
import amazon from '@/assets/images/logos/amazon.svg';
import apple from '@/assets/images/logos/apple.svg';
import asana from '@/assets/images/logos/asana.svg';
import google from '@/assets/images/logos/google.svg';
import meta from '@/assets/images/logos/meta.svg';
import shell from '@/assets/images/logos/shell.svg';
import spotify from '@/assets/images/logos/spotify.svg';
import starbucks from '@/assets/images/logos/starbucks.svg';
export const companyData = [{
  name: 'Amazon Inc.',
  website: 'www.amazon.com',
  image: amazon,
  location: 'Seattle, WA',
  industry: 'eCommerce',
  founded: 1994,
  description: 'Amazon.com, Inc. is an American multinational technology company focusing on e-commerce, cloud computing, digital streaming, and artificial intelligence. It’s one of the Big Five tech companies alongside Google, Apple, Microsoft, and Meta.',
  employees: '1.5M+',
  revenue: '$514B',
  ceo: 'Andy Jassy',
  ticker: 'AMZN',
  exchange: 'Nasdaq',
  rating: 4
}, {
  name: 'Apple Inc.',
  website: 'www.apple.com',
  image: apple,
  location: 'Cupertino, CA',
  industry: 'Technology',
  founded: 1976,
  description: 'Apple Inc. is an American multinational technology company that designs, develops, and sells consumer electronics, software, and online services. It’s one of the Big Five tech companies alongside Google, Amazon, Microsoft, and Meta.',
  employees: '164K+',
  revenue: '$394B',
  ceo: 'Tim Cook',
  ticker: 'AAPL',
  exchange: 'Nasdaq',
  rating: 4
}, {
  name: 'Starbucks Corporation',
  website: 'www.starbucks.com',
  image: starbucks,
  location: 'Seattle, WA',
  industry: 'Coffeehouse',
  founded: 1971,
  description: 'Starbucks Corporation is an American multinational chain of coffeehouses and roastery reserves. It’s the world’s largest coffeehouse chain and a premier roaster and retailer of specialty coffee.',
  employees: '400K+',
  revenue: '$36B',
  ceo: 'Laxman Narasimhan',
  ticker: 'SBUX',
  exchange: 'Nasdaq',
  rating: 4
}, {
  name: 'Meta Platforms, Inc.',
  website: 'www.meta.com',
  image: meta,
  location: 'Menlo Park, CA',
  industry: 'Social Media',
  founded: 2004,
  description: 'Meta Platforms, Inc. is an American multinational technology conglomerate. It owns Facebook, Instagram, WhatsApp, and Quest VR products, focusing on social networking, virtual reality, and the metaverse.',
  employees: '66K+',
  revenue: '$134B',
  ceo: 'M.Zuckerberg',
  ticker: 'META',
  exchange: 'Nasdaq',
  rating: 4
}, {
  name: 'Spotify Technology S.A.',
  website: 'www.spotify.com',
  image: spotify,
  location: 'Stockholm, Sweden',
  industry: 'Music Streaming',
  founded: 2006,
  description: 'Spotify Technology S.A. is a Swedish audio streaming and media services provider. It’s one of the world’s largest music streaming service providers with millions of active users worldwide.',
  employees: '8.9K+',
  revenue: '$13B',
  ceo: 'Daniel Ek',
  ticker: 'SPOT',
  exchange: 'NYSE',
  rating: 4
}, {
  name: 'Google LLC',
  website: 'www.google.com',
  image: google,
  location: 'Mountain View, CA',
  industry: 'Technology',
  founded: 1998,
  description: 'Google LLC is an American multinational technology company focusing on search, online advertising, cloud computing, and artificial intelligence. It’s a subsidiary of Alphabet Inc.',
  employees: '182K+',
  revenue: '$307B',
  ceo: 'Sundar Pichai',
  ticker: 'GOOGL',
  exchange: 'Nasdaq',
  rating: 4
}, {
  name: 'Airbnb, Inc.',
  website: 'www.airbnb.com',
  image: airbnb,
  location: 'San Francisco, CA',
  industry: 'Travel & Hospitality',
  founded: 2008,
  description: 'Airbnb, Inc. is an American company operating an online marketplace for short-term homestays and experiences. It connects hosts with travelers looking for accommodations worldwide.',
  employees: '6K+',
  revenue: '$9.9B',
  ceo: 'Brian Chesky',
  ticker: 'ABNB',
  exchange: 'Nasdaq',
  rating: 4
}, {
  name: 'Shell plc',
  website: 'www.shell.com',
  image: shell,
  location: 'London, UK',
  industry: 'Energy & Oil',
  founded: 1907,
  description: 'Shell plc is a British multinational oil and gas company. It is one of the largest energy companies in the world, involved in oil, natural gas, and renewable energy development.',
  employees: '90K+',
  revenue: '$381B',
  ceo: 'Wael Sawan',
  ticker: 'SHEL',
  exchange: 'NYSE',
  rating: 4
}, {
  name: 'Asana, Inc.',
  website: 'www.asana.com',
  image: asana,
  location: 'San Francisco, CA',
  industry: 'Work Management',
  founded: 2008,
  description: 'Asana, Inc. is an American software company that provides a work management platform for teams to organize, track, and manage their work. It’s widely used for task, project, and workflow management.',
  employees: '1.7K+',
  revenue: '$652M',
  ceo: 'D. Moskovitz',
  ticker: 'ASAN',
  exchange: 'NYSE',
  rating: 4
}];