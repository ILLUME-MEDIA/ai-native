export const leaveStatData = [{
  icon: 'calendar',
  value: 128,
  change: 4.8,
  title: 'Total leave requests'
}, {
  icon: 'checks',
  value: 92,
  change: 2.3,
  title: 'Approved leaves'
}, {
  icon: 'hourglass',
  value: 21,
  change: 1.2,
  title: 'Pending approvals'
}, {
  icon: 'x',
  value: 15,
  change: -0.5,
  title: 'Rejected leaves'
}, {
  icon: 'clock',
  value: 2.3,
  change: 0.7,
  title: 'Average leave duration',
  unit: 'days/leave'
}];
export const leaveData = [{
  id: 'EMP-1024',
  name: 'Alex Johnson',
  department: 'Design',
  dataFrom: '24 Oct 2025',
  dataTo: '25 Oct 2025',
  leaveType: 'Sick Leave',
  reason: 'Flu and recovery',
  status: 'Pending',
  appliedOn: '22 Oct 2025',
  approvedBy: '--'
}, {
  id: 'EMP-1078',
  name: 'Maria Smith',
  department: 'HR',
  dataFrom: '10 Oct 2025',
  dataTo: '12 Oct 2025',
  leaveType: 'Casual Leave',
  reason: 'Family event',
  status: 'Approved',
  appliedOn: '08 Oct 2025',
  approvedBy: 'John Adams'
}, {
  id: 'EMP-1091',
  name: 'David Lee',
  department: 'IT',
  dataFrom: '18 Sep 2025',
  dataTo: '19 Sep 2025',
  leaveType: 'Paid Leave',
  reason: 'Short vacation',
  status: 'Rejected',
  appliedOn: '15 Sep 2025',
  approvedBy: 'Maria Smith'
}, {
  id: 'EMP-1115',
  name: 'Emma Davis',
  department: 'Finance',
  dataFrom: '02 Oct 2025',
  dataTo: '03 Oct 2025',
  leaveType: 'Casual Leave',
  reason: 'Personal errand',
  status: 'Approved',
  appliedOn: '29 Sep 2025',
  approvedBy: 'John Adams'
}, {
  id: 'EMP-1156',
  name: 'Noah Wilson',
  department: 'Marketing',
  dataFrom: '07 Oct 2025',
  dataTo: '09 Oct 2025',
  leaveType: 'Sick Leave',
  reason: 'Fever',
  status: 'Approved',
  appliedOn: '05 Oct 2025',
  approvedBy: 'Maria Smith'
}, {
  id: 'EMP-1182',
  name: 'Olivia Brown',
  department: 'Operations',
  dataFrom: '20 Sep 2025',
  dataTo: '22 Sep 2025',
  leaveType: 'Maternity Leave',
  reason: 'Pre-delivery care',
  status: 'Pending',
  appliedOn: '18 Sep 2025',
  approvedBy: '--'
}, {
  id: 'EMP-1199',
  name: 'Daniel Clark',
  department: 'Support',
  dataFrom: '05 Sep 2025',
  dataTo: '06 Sep 2025',
  leaveType: 'Casual Leave',
  reason: 'Family function',
  status: 'Approved',
  appliedOn: '03 Sep 2025',
  approvedBy: 'John Adams'
}, {
  id: 'EMP-1210',
  name: 'Sarah Miller',
  department: 'Admin',
  dataFrom: '25 Aug 2025',
  dataTo: '26 Aug 2025',
  leaveType: 'Casual Leave',
  reason: 'Out of town',
  status: 'Approved',
  appliedOn: '22 Aug 2025',
  approvedBy: 'Maria Smith'
}, {
  id: 'EMP-1225',
  name: 'Lucas Green',
  department: 'Sales',
  dataFrom: '15 Aug 2025',
  dataTo: '16 Aug 2025',
  leaveType: 'Paid Leave',
  reason: 'Wedding attendance',
  status: 'Approved',
  appliedOn: '12 Aug 2025',
  approvedBy: 'John Adams'
}, {
  id: 'EMP-1242',
  name: 'Henry Walker',
  department: 'Logistics',
  dataFrom: '10 Jul 2025',
  dataTo: '12 Jul 2025',
  leaveType: 'Casual Leave',
  reason: 'Travel with family',
  status: 'Approved',
  appliedOn: '08 Jul 2025',
  approvedBy: 'Maria Smith'
}];