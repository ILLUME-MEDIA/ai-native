export const holidayStatData = [{
  icon: 'calendar',
  title: 'Total Holidays',
  value: 14
}, {
  icon: 'flag',
  title: 'Federal Holidays',
  value: 11
}, {
  icon: 'filter-2',
  title: 'Optional Holidays',
  value: 3
}, {
  icon: 'calendar-clock',
  title: 'Upcoming Holidays',
  value: 5
}, {
  icon: 'circle-check',
  title: 'Active',
  value: 12
}, {
  icon: 'minus',
  title: 'Inactive',
  value: 2
}];
export const holidayData = [{
  name: 'New Year’s Day',
  date: '01 Jan 2026',
  day: 'Thursday',
  description: 'Celebration of the first day of the year',
  status: 'active',
  optional: 'no',
  createdOn: '15 Dec 2025',
  addedBy: 'Admin'
}, {
  name: 'Martin Luther King Jr. Day',
  date: '19 Jan 2026',
  day: 'Monday',
  description: 'Honoring the civil rights leader Martin Luther King Jr.',
  status: 'active',
  optional: 'no',
  createdOn: '03 Jan 2026',
  addedBy: 'HR Dept'
}, {
  name: 'Presidents’ Day',
  date: '16 Feb 2026',
  day: 'Monday',
  description: 'Honoring George Washington and all U.S. presidents',
  status: 'active',
  optional: 'no',
  createdOn: '10 Jan 2026',
  addedBy: 'HR Admin'
}, {
  name: 'Memorial Day',
  date: '25 May 2026',
  day: 'Monday',
  description: 'Honoring U.S. military personnel who died in service',
  status: 'active',
  optional: 'no',
  createdOn: '15 Apr 2026',
  addedBy: 'Admin'
}, {
  name: 'Juneteenth National Independence Day',
  date: '19 Jun 2026',
  day: 'Friday',
  description: 'Commemorating the end of slavery in the United States',
  status: 'active',
  optional: 'no',
  createdOn: '20 May 2026',
  addedBy: 'HR Dept'
}, {
  name: 'Independence Day',
  date: '04 Jul 2026',
  day: 'Saturday',
  description: 'Celebration of U.S. independence from Great Britain',
  status: 'active',
  optional: 'no',
  createdOn: '05 Jun 2026',
  addedBy: 'HR Team'
}, {
  name: 'Labor Day',
  date: '07 Sep 2026',
  day: 'Monday',
  description: 'Honoring workers and labor rights',
  status: 'active',
  optional: 'no',
  createdOn: '10 Aug 2026',
  addedBy: 'HR Admin'
}, {
  name: 'Columbus Day',
  date: '12 Oct 2026',
  day: 'Monday',
  description: 'Commemorating the arrival of Christopher Columbus',
  status: 'active',
  optional: 'yes',
  createdOn: '15 Sep 2026',
  addedBy: 'Admin'
}, {
  name: 'Thanksgiving Day',
  date: '26 Nov 2026',
  day: 'Thursday',
  description: 'National day of gratitude and family gatherings',
  status: 'active',
  optional: 'no',
  createdOn: '01 Nov 2026',
  addedBy: 'Admin'
}, {
  name: 'Black Friday',
  date: '27 Nov 2026',
  day: 'Friday',
  description: 'Day after Thanksgiving, observed in some companies',
  status: 'optional',
  optional: 'yes',
  createdOn: '05 Nov 2026',
  addedBy: 'HR Dept'
}, {
  name: 'Christmas Eve',
  date: '24 Dec 2026',
  day: 'Thursday',
  description: 'Observed as an early company closure day',
  status: 'optional',
  optional: 'yes',
  createdOn: '01 Dec 2026',
  addedBy: 'HR Admin'
}, {
  name: 'Christmas Day',
  date: '25 Dec 2026',
  day: 'Friday',
  description: 'Celebration of Christmas Day',
  status: 'active',
  optional: 'no',
  createdOn: '10 Dec 2026',
  addedBy: 'HR Team'
}];