export const attendanceStatData = [{
  title: 'Total working days',
  value: 22,
  icon: 'calendar-clock',
  change: 5
}, {
  title: 'Days present',
  value: 18,
  icon: 'user-check',
  change: 2.4
}, {
  title: 'Days on leave',
  value: 2,
  icon: 'plane',
  change: -1.0
}, {
  title: 'Days absent',
  value: 1,
  icon: 'user-circle',
  change: 1
}, {
  title: 'Average working hours',
  value: 9.2,
  unit: 'hrs/day',
  icon: 'clock',
  change: 0.8
}];
export const attendanceData = [{
  date: '27 Oct 2025',
  status: 'present',
  shiftType: 'Day Shift',
  clockIn: '09:03 AM',
  clockOut: '06:50 PM',
  production: '8h 25m',
  breakTime: '0h 50m',
  overtime: '0h 15m',
  progress: 90,
  totalHours: '9h 30m',
  leaveType: '--',
  approval: 'approved',
  user: {
    name: 'Maria Smith'
  }
}, {
  date: '26 Oct 2025',
  status: 'present',
  shiftType: 'Day Shift',
  clockIn: '09:10 AM',
  clockOut: '07:05 PM',
  production: '8h 30m',
  breakTime: '1h 00m',
  overtime: '0h 25m',
  progress: 88,
  totalHours: '9h 55m',
  leaveType: '--',
  approval: 'approved',
  user: {
    name: 'Maria Smith'
  }
}, {
  date: '25 Oct 2025',
  status: 'late',
  shiftType: 'Day Shift',
  clockIn: '09:45 AM',
  clockOut: '07:30 PM',
  production: '8h 10m',
  breakTime: '0h 55m',
  overtime: '0h 00m',
  progress: 75,
  totalHours: '9h 05m',
  leaveType: '--',
  approval: 'approved',
  user: {
    name: 'Maria Smith'
  }
}, {
  date: '24 Oct 2025',
  status: 'on-leave',
  shiftType: '--',
  clockIn: '--',
  clockOut: '--',
  production: '--',
  breakTime: '--',
  overtime: '--',
  progress: 0,
  totalHours: '--',
  leaveType: 'Sick Leave',
  approval: 'approved',
  user: {
    name: 'Maria Smith'
  }
}, {
  date: '23 Oct 2025',
  status: 'present',
  shiftType: 'Night Shift',
  clockIn: '07:20 PM',
  clockOut: '04:10 PM',
  production: '8h 35m',
  breakTime: '0h 40m',
  overtime: '0h 25m',
  progress: 92,
  totalHours: '9h 40m',
  leaveType: '--',
  approval: 'approved',
  user: {
    name: 'Maria Smith'
  }
}, {
  date: '22 Oct 2025',
  status: 'half-day',
  shiftType: 'Day Shift',
  clockIn: '09:40 AM',
  clockOut: '01:15 PM',
  production: '3h 30m',
  breakTime: '0h 15m',
  overtime: '--',
  progress: 40,
  totalHours: '3h 45m',
  leaveType: '--',
  approval: 'pending',
  user: {
    name: 'Maria Smith'
  }
}, {
  date: '21 Oct 2025',
  status: 'absent',
  shiftType: '--',
  clockIn: '--',
  clockOut: '--',
  production: '--',
  breakTime: '--',
  overtime: '--',
  progress: 0,
  totalHours: '--',
  leaveType: '--',
  approval: 'rejected',
  user: {
    name: 'Maria Smith'
  }
}, {
  date: '20 Oct 2025',
  status: 'present',
  shiftType: 'Day Shift',
  clockIn: '09:00 AM',
  clockOut: '06:40 PM',
  production: '8h 15m',
  breakTime: '1h 00m',
  overtime: '0h 20m',
  progress: 88,
  totalHours: '9h 35m',
  leaveType: '--',
  approval: 'approved',
  user: {
    name: 'Maria Smith'
  }
}, {
  date: '19 Oct 2025',
  status: 'present',
  shiftType: 'Day Shift',
  clockIn: '09:12 AM',
  clockOut: '06:55 PM',
  production: '8h 40m',
  breakTime: '0h 55m',
  overtime: '0h 10m',
  progress: 90,
  totalHours: '9h 45m',
  leaveType: '--',
  approval: 'approved',
  user: {
    name: 'Maria Smith'
  }
}, {
  date: '18 Oct 2025',
  status: 'present',
  shiftType: 'Day Shift',
  clockIn: '09:08 AM',
  clockOut: '06:48 PM',
  production: '8h 20m',
  breakTime: '0h 50m',
  overtime: '0h 15m',
  progress: 88,
  totalHours: '9h 25m',
  leaveType: '--',
  approval: 'approved',
  user: {
    name: 'Maria Smith'
  }
}, {
  date: '17 Oct 2025',
  status: 'on-leave',
  shiftType: '--',
  clockIn: '--',
  clockOut: '--',
  production: '--',
  breakTime: '--',
  overtime: '--',
  progress: 0,
  totalHours: '--',
  leaveType: 'Casual Leave',
  approval: 'approved',
  user: {
    name: 'Maria Smith'
  }
}, {
  date: '16 Oct 2025',
  status: 'present',
  shiftType: 'Night Shift',
  clockIn: '07:10 PM',
  clockOut: '03:50 AM',
  production: '8h 00m',
  breakTime: '0h 45m',
  overtime: '0h 25m',
  progress: 86,
  totalHours: '9h 10m',
  leaveType: '--',
  approval: 'approved',
  user: {
    name: 'Maria Smith'
  }
}, {
  date: '15 Oct 2025',
  status: 'late',
  shiftType: 'Day Shift',
  clockIn: '09:55 AM',
  clockOut: '07:20 PM',
  production: '7h 55m',
  breakTime: '1h 05m',
  overtime: '0h 15m',
  progress: 70,
  totalHours: '9h 15m',
  leaveType: '--',
  approval: 'approved',
  user: {
    name: 'Maria Smith'
  }
}];