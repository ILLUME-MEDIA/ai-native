import user1 from '@/assets/images/users/user-1.jpg';
import user10 from '@/assets/images/users/user-10.jpg';
import user2 from '@/assets/images/users/user-2.jpg';
import user3 from '@/assets/images/users/user-3.jpg';
import user4 from '@/assets/images/users/user-4.jpg';
import user5 from '@/assets/images/users/user-5.jpg';
import user6 from '@/assets/images/users/user-6.jpg';
import user7 from '@/assets/images/users/user-7.jpg';
import user8 from '@/assets/images/users/user-8.jpg';
import user9 from '@/assets/images/users/user-9.jpg';
export const payrollData = [{
  id: 'PAY-001',
  employee: {
    image: user3,
    name: 'Samantha Green',
    email: 'samantha.green@company.com'
  },
  department: 'Human Resources',
  designation: 'HR Manager',
  date: 'Oct 2025',
  salary: '$6,200',
  allowance: '$500',
  actualSalary: '$6,700',
  deductions: '$150',
  netPay: '$6,550',
  status: 'paid'
}, {
  id: 'PAY-002',
  employee: {
    image: user6,
    name: 'David Lee',
    email: 'david.lee@company.com'
  },
  department: 'IT',
  designation: 'Software Engineer',
  date: 'Oct 2025',
  salary: '$5,000',
  allowance: '$400',
  actualSalary: '$5,400',
  deductions: '$100',
  netPay: '$5,300',
  status: 'processing'
}, {
  id: 'PAY-003',
  employee: {
    image: user8,
    name: 'Maria Smith',
    email: 'maria.smith@company.com'
  },
  department: 'Finance',
  designation: 'Accountant',
  date: 'Oct 2025',
  salary: '$4,800',
  allowance: '$250',
  actualSalary: '$5,050',
  deductions: '$100',
  netPay: '$4,950',
  status: 'on-hold'
}, {
  id: 'PAY-004',
  employee: {
    image: user4,
    name: 'Michael Adams',
    email: 'michael.adams@company.com'
  },
  department: 'Marketing',
  designation: 'Marketing Executive',
  date: 'Oct 2025',
  salary: '$4,200',
  allowance: '$300',
  actualSalary: '$4,500',
  deductions: '$120',
  netPay: '$4,380',
  status: 'paid'
}, {
  id: 'PAY-005',
  employee: {
    image: user1,
    name: 'Olivia Brown',
    email: 'olivia.brown@company.com'
  },
  department: 'Design',
  designation: 'UI/UX Designer',
  date: 'Oct 2025',
  salary: '$4,600',
  allowance: '$400',
  actualSalary: '$5,000',
  deductions: '$80',
  netPay: '$4,920',
  status: 'paid'
}, {
  id: 'PAY-006',
  employee: {
    image: user2,
    name: 'Daniel Carter',
    email: 'daniel.carter@company.com'
  },
  department: 'Operations',
  designation: 'Operations Lead',
  date: 'Oct 2025',
  salary: '$5,500',
  allowance: '$600',
  actualSalary: '$6,100',
  deductions: '$200',
  netPay: '$5,900',
  status: 'paid'
}, {
  id: 'PAY-007',
  employee: {
    image: user5,
    name: 'Emily Davis',
    email: 'emily.davis@company.com'
  },
  department: 'Admin',
  designation: 'Office Administrator',
  date: 'Oct 2025',
  salary: '$3,800',
  allowance: '$250',
  actualSalary: '$4,050',
  deductions: '$50',
  netPay: '$4,000',
  status: 'processing'
}, {
  id: 'PAY-008',
  employee: {
    image: user9,
    name: 'James Walker',
    email: 'james.walker@company.com'
  },
  department: 'Sales',
  designation: 'Sales Manager',
  date: 'Oct 2025',
  salary: '$6,000',
  allowance: '$800',
  actualSalary: '$6,800',
  deductions: '$200',
  netPay: '$6,600',
  status: 'paid'
}, {
  id: 'PAY-009',
  employee: {
    image: user7,
    name: 'Sophia Martinez',
    email: 'sophia.martinez@company.com'
  },
  department: 'Customer Support',
  designation: 'Support Specialist',
  date: 'Oct 2025',
  salary: '$3,900',
  allowance: '$150',
  actualSalary: '$4,050',
  deductions: '$70',
  netPay: '$3,980',
  status: 'processing'
}, {
  id: 'PAY-010',
  employee: {
    image: user10,
    name: 'Henry Clark',
    email: 'henry.clark@company.com'
  },
  department: 'Logistics',
  designation: 'Warehouse Supervisor',
  date: 'Oct 2025',
  salary: '$4,400',
  allowance: '$200',
  actualSalary: '$4,600',
  deductions: '$80',
  netPay: '$4,520',
  status: 'paid'
}, {
  id: 'PAY-011',
  employee: {
    image: user7,
    name: 'Isabella Johnson',
    email: 'isabella.johnson@company.com'
  },
  department: 'Legal',
  designation: 'Legal Advisor',
  date: 'Oct 2025',
  salary: '$5,800',
  allowance: '$350',
  actualSalary: '$6,150',
  deductions: '$180',
  netPay: '$5,970',
  status: 'paid'
}, {
  id: 'PAY-012',
  employee: {
    image: user2,
    name: 'Liam Turner',
    email: 'liam.turner@company.com'
  },
  department: 'Engineering',
  designation: 'QA Engineer',
  date: 'Oct 2025',
  salary: '$4,700',
  allowance: '$200',
  actualSalary: '$4,900',
  deductions: '$90',
  netPay: '$4,810',
  status: 'processing'
}, {
  id: 'PAY-013',
  employee: {
    image: user9,
    name: 'Charlotte Evans',
    email: 'charlotte.evans@company.com'
  },
  department: 'Public Relations',
  designation: 'PR Manager',
  date: 'Oct 2025',
  salary: '$5,200',
  allowance: '$300',
  actualSalary: '$5,500',
  deductions: '$120',
  netPay: '$5,380',
  status: 'on-hold'
}, {
  id: 'PAY-014',
  employee: {
    image: user4,
    name: 'Benjamin Scott',
    email: 'benjamin.scott@company.com'
  },
  department: 'Procurement',
  designation: 'Purchase Officer',
  date: 'Oct 2025',
  salary: '$4,300',
  allowance: '$250',
  actualSalary: '$4,550',
  deductions: '$70',
  netPay: '$4,480',
  status: 'paid'
}, {
  id: 'PAY-015',
  employee: {
    image: user10,
    name: 'Grace Mitchell',
    email: 'grace.mitchell@company.com'
  },
  department: 'Research & Development',
  designation: 'Data Scientist',
  date: 'Oct 2025',
  salary: '$6,700',
  allowance: '$600',
  actualSalary: '$7,300',
  deductions: '$250',
  netPay: '$7,050',
  status: 'paid'
}];