import user10 from '@/assets/images/users/user-10.jpg';
import user2 from '@/assets/images/users/user-2.jpg';
import user3 from '@/assets/images/users/user-3.jpg';
import user4 from '@/assets/images/users/user-4.jpg';
import user5 from '@/assets/images/users/user-5.jpg';
import user6 from '@/assets/images/users/user-6.jpg';
import user7 from '@/assets/images/users/user-7.jpg';
import user8 from '@/assets/images/users/user-8.jpg';
import user9 from '@/assets/images/users/user-9.jpg';
export const taskData = [{
  title: 'Complete Presentation Slides for Meeting',
  createdAtDate: '9 May, 2025',
  createdAtTime: '10:10 AM',
  assignee: {
    name: 'Cruise ⚒️',
    members: 2,
    image: user2
  },
  dueDate: 'Today',
  totalTask: 7,
  completedTask: 0,
  status: 'new',
  priority: 'high',
  comments: 1
}, {
  title: 'Finalize Product Roadmap for Launch',
  createdAtDate: '8 Oct, 2025',
  createdAtTime: '2:30 PM',
  assignee: {
    name: 'Maria 💻',
    members: 2,
    image: user5
  },
  dueDate: '29 Oct, 2025',
  totalTask: 10,
  completedTask: 5,
  status: 'in-progress',
  priority: 'medium',
  comments: 14
}, {
  title: 'Design Marketing Campaign Assets',
  createdAtDate: '6 Oct, 2025',
  createdAtTime: '5:45 PM',
  assignee: {
    name: 'Kevin',
    members: 1,
    image: user3
  },
  dueDate: '29 Oct, 2025',
  totalTask: 8,
  completedTask: 6,
  status: 'in-progress',
  priority: 'high',
  comments: 9
}, {
  title: 'Prepare Monthly Financial Report',
  createdAtDate: '4 Oct, 2025',
  createdAtTime: '11:00 AM',
  assignee: {
    name: 'Thomas 🏠',
    members: 1,
    image: user4
  },
  dueDate: '20 Sep, 2025',
  totalTask: 5,
  completedTask: 2,
  status: 'in-progress',
  priority: 'medium',
  comments: 6
}, {
  title: 'Conduct Team Retrospective Meeting',
  createdAtDate: '2 Oct, 2025',
  createdAtTime: '4:00 PM',
  assignee: {
    name: 'James',
    members: 1,
    image: user6
  },
  dueDate: 'Yesterday',
  totalTask: 4,
  completedTask: 4,
  status: 'new',
  priority: 'low',
  comments: 2
}, {
  title: 'Review UI/UX Prototype for Dashboard',
  createdAtDate: '1 Oct, 2025',
  createdAtTime: '9:45 AM',
  assignee: {
    name: 'Sophia 🚀',
    members: 3,
    image: user7
  },
  dueDate: '22 Oct, 2025',
  totalTask: 6,
  completedTask: 1,
  status: 'new',
  priority: 'high',
  comments: 11
}, {
  title: 'Update Documentation and API References',
  createdAtDate: '28 Sep, 2025',
  createdAtTime: '1:20 PM',
  assignee: {
    name: 'Liam',
    members: 1,
    image: user8
  },
  dueDate: '19 Sep, 2025',
  totalTask: 8,
  completedTask: 7,
  status: 'cancelled',
  priority: 'medium',
  comments: 5
}, {
  title: 'Implement User Authentication Module',
  createdAtDate: '10 Oct, 2025',
  createdAtTime: '9:00 AM',
  assignee: {
    name: 'Olivia',
    members: 2,
    image: user9
  },
  dueDate: 'Tomorrow',
  totalTask: 10,
  completedTask: 3,
  status: 'new',
  priority: 'high',
  comments: 8
}, {
  title: 'Write Test Cases for API Endpoints',
  createdAtDate: '9 Oct, 2025',
  createdAtTime: '10:45 AM',
  assignee: {
    name: 'Ethan',
    members: 1,
    image: user10
  },
  dueDate: '12 Nov, 2025',
  totalTask: 8,
  completedTask: 1,
  status: 'in-progress',
  priority: 'medium',
  comments: 3
}, {
  title: 'Migrate Legacy Data to New Database',
  createdAtDate: '5 Oct, 2025',
  createdAtTime: '8:00 PM',
  assignee: {
    name: 'Charlotte',
    members: 1,
    image: user4
  },
  dueDate: 'Next Week',
  totalTask: 12,
  completedTask: 2,
  status: 'in-progress',
  priority: 'medium',
  comments: 10
}, {
  title: 'QA Review and Regression Testing',
  createdAtDate: '3 Oct, 2025',
  createdAtTime: '3:10 PM',
  assignee: {
    name: 'Grace',
    members: 1,
    image: user2
  },
  dueDate: '12 Sep, 2025',
  totalTask: 10,
  completedTask: 9,
  status: 'cancelled',
  priority: 'high',
  comments: 17
}, {
  title: 'Optimize Application Performance Metrics',
  createdAtDate: '1 Oct, 2025',
  createdAtTime: '12:05 PM',
  assignee: {
    name: 'Noah',
    members: 1,
    image: user6
  },
  dueDate: '18 Oct, 2025',
  totalTask: 7,
  completedTask: 2,
  status: 'in-progress',
  priority: 'medium',
  comments: 6
}];