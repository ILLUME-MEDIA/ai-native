export const giftCardData = [{
  code: 'GFT-A1001',
  recipient: {
    name: 'Olivia Jenkins',
    email: 'olivia.jenkins@mail.com'
  },
  type: 'digital',
  value: '$100',
  balance: '$45',
  status: 'active',
  issuedOn: '12 Apr 2025',
  expiresOn: '12 Apr 2026'
}, {
  code: 'GFT-A1002',
  recipient: {
    name: 'Liam Henderson',
    email: 'liam.henderson@mail.com'
  },
  type: 'physical',
  value: '$50',
  balance: '$0',
  status: 'redeemed',
  issuedOn: '5 Feb 2025',
  expiresOn: '5 Feb 2026'
}, {
  code: 'GFT-A1003',
  recipient: {
    name: 'Emma Wallace',
    email: 'emma.wallace@mail.com'
  },
  type: 'digital',
  value: '$200',
  balance: '$200',
  status: 'pending',
  issuedOn: '20 May 2025',
  expiresOn: '20 May 2026'
}, {
  code: 'GFT-A1004',
  recipient: {
    name: 'Noah Parker',
    email: 'noah.parker@mail.com'
  },
  type: 'physical',
  value: '$150',
  balance: '$75',
  status: 'active',
  issuedOn: '2 Mar 2025',
  expiresOn: '2 Mar 2026'
}, {
  code: 'GFT-A1005',
  recipient: {
    name: 'Ava Reed',
    email: 'ava.reed@mail.com'
  },
  type: 'digital',
  value: '$75',
  balance: '$0',
  status: 'expired',
  issuedOn: '10 Jan 2024',
  expiresOn: '10 Jan 2025'
}, {
  code: 'GFT-A1006',
  recipient: {
    name: 'Lucas Gray',
    email: 'lucas.gray@mail.com'
  },
  type: 'digital',
  value: '$100',
  balance: '$100',
  status: 'pending',
  issuedOn: '25 May 2025',
  expiresOn: '25 May 2026'
}, {
  code: 'GFT-A1007',
  recipient: {
    name: 'Isabella Moore',
    email: 'isabella.moore@mail.com'
  },
  type: 'physical',
  value: '$250',
  balance: '$75',
  status: 'active',
  issuedOn: '15 Mar 2025',
  expiresOn: '15 Mar 2026'
}, {
  code: 'GFT-A1008',
  recipient: {
    name: 'Elijah Bennett',
    email: 'elijah.bennett@mail.com'
  },
  type: 'digital',
  value: '$75',
  balance: '$0',
  status: 'redeemed',
  issuedOn: '5 Feb 2025',
  expiresOn: '5 Feb 2026'
}, {
  code: 'GFT-A1009',
  recipient: {
    name: 'Harper Collins',
    email: 'harper.collins@mail.com'
  },
  type: 'physical',
  value: '$120',
  balance: '$40',
  status: 'active',
  issuedOn: '18 Apr 2025',
  expiresOn: '18 Apr 2026'
}, {
  code: 'GFT-A1010',
  recipient: {
    name: 'Sophia Adams',
    email: 'sophia.adams@mail.com'
  },
  type: 'digital',
  value: '$200',
  balance: '$0',
  status: 'expired',
  issuedOn: '1 Mar 2024',
  expiresOn: '1 Mar 2025'
}, {
  code: 'GFT-A1011',
  recipient: {
    name: 'Jack Thompson',
    email: 'jack.thompson@mail.com'
  },
  type: 'physical',
  value: '$300',
  balance: '$260',
  status: 'active',
  issuedOn: '8 Jan 2025',
  expiresOn: '8 Jan 2026'
}, {
  code: 'GFT-A1012',
  recipient: {
    name: 'Ella Johnson',
    email: 'ella.johnson@mail.com'
  },
  type: 'digital',
  value: '$150',
  balance: '$0',
  status: 'redeemed',
  issuedOn: '15 Feb 2025',
  expiresOn: '15 Feb 2026'
}];