export const discounts = [{
  name: 'Summer Sale',
  details: 'Applicable on all summer collection items',
  type: 'percentage',
  value: '25%',
  startDate: '1 May, 2025',
  endDate: '31 May, 2025',
  minPurchase: '$50',
  maxDiscount: '$150',
  status: 'active'
}, {
  name: 'New User Offer',
  details: 'Only for first purchase customers',
  type: 'flat',
  value: '$10',
  startDate: '10 Mar, 2025',
  endDate: '31 Dec, 2025',
  minPurchase: '$30',
  maxDiscount: '$10',
  status: 'active'
}, {
  name: 'Weekend Special',
  details: 'Valid only on Saturdays and Sundays',
  type: 'percentage',
  value: '15%',
  startDate: '1 Jun, 2025',
  endDate: '30 Sep, 2025',
  minPurchase: '$20',
  maxDiscount: '$100',
  status: 'scheduled'
}, {
  name: 'Black Friday Mega Deal',
  details: 'Sitewide discount for limited period',
  type: 'percentage',
  value: '40%',
  startDate: '25 Nov, 2025',
  endDate: '28 Nov, 2025',
  minPurchase: '$100',
  maxDiscount: '$300',
  status: 'expired'
}, {
  name: 'Holiday Bundle Offer',
  details: 'Buy 2 get 1 free — auto-applied at checkout',
  type: 'bogo',
  value: '-',
  startDate: '15 Dec, 2025',
  endDate: '31 Dec, 2025',
  minPurchase: '$0',
  maxDiscount: '-',
  status: 'active'
}, {
  name: 'Flash Friday',
  details: 'Limited-time 24-hour deal',
  type: 'percentage',
  value: '30%',
  startDate: '7 Feb, 2025',
  endDate: '7 Feb, 2025',
  minPurchase: '$20',
  maxDiscount: '$120',
  status: 'active'
}, {
  name: 'New Year Celebration',
  details: 'Applicable sitewide for 2025',
  type: 'flat',
  value: '$25',
  startDate: '30 Dec, 2024',
  endDate: '5 Jan, 2025',
  minPurchase: '$50',
  maxDiscount: '$25',
  status: 'active'
}, {
  name: 'Student Discount',
  details: 'For verified student accounts',
  type: 'percentage',
  value: '10%',
  startDate: '1 Jan, 2025',
  endDate: '31 Dec, 2025',
  minPurchase: '$10',
  maxDiscount: '$50',
  status: 'active'
}, {
  name: 'Referral Reward',
  details: 'Applies on both referrer & referee',
  type: 'flat',
  value: '$15',
  startDate: '1 Feb, 2025',
  endDate: '31 Jul, 2025',
  minPurchase: '$0',
  maxDiscount: '$15',
  status: 'active'
}, {
  name: 'Clearance Offer',
  details: 'Applies on clearance and end-of-season items',
  type: 'percentage',
  value: '40%',
  startDate: '1 Aug, 2025',
  endDate: '31 Aug, 2025',
  minPurchase: '$0',
  maxDiscount: '$200',
  status: 'expired'
}, {
  name: 'App Exclusive',
  details: 'Only for purchases via mobile app',
  type: 'flat',
  value: '$5',
  startDate: '15 Mar, 2025',
  endDate: '15 Sep, 2025',
  minPurchase: '$25',
  maxDiscount: '$5',
  status: 'active'
}, {
  name: 'Weekend Flash Sale',
  details: 'Automatically applied every Friday–Sunday',
  type: 'percentage',
  value: '18%',
  startDate: '1 Jul, 2025',
  endDate: '31 Dec, 2025',
  minPurchase: '$30',
  maxDiscount: '$90',
  status: 'scheduled'
}];