import { getColor } from '@/utils/helpers';
// basic candlestick chart

const data = [['24 January, 2025', 2320.26, 2320.26, 2287.3, 2362.94], ['25 January, 2025', 2300, 2291.3, 2288.26, 2308.38], ['28 January, 2025', 2295.35, 2346.5, 2295.35, 2346.92], ['29 January, 2025', 2347.22, 2358.98, 2337.35, 2363.8], ['30 January, 2025', 2360.75, 2382.48, 2347.89, 2383.76], ['31 January, 2025', 2383.43, 2385.42, 2371.23, 2391.82], ['1 February, 2025', 2377.41, 2419.02, 2369.57, 2421.15], ['4 February, 2025', 2425.92, 2428.15, 2417.58, 2440.38], ['5 February, 2025', 2411, 2433.13, 2403.3, 2437.42], ['6 February, 2025', 2432.68, 2434.48, 2427.7, 2441.73], ['7 February, 2025', 2430.69, 2418.53, 2394.22, 2433.89], ['8 February, 2025', 2416.62, 2432.4, 2414.4, 2443.03], ['18 February, 2025', 2441.91, 2421.56, 2415.43, 2444.8], ['19 February, 2025', 2420.26, 2382.91, 2373.53, 2427.07], ['20 February, 2025', 2383.49, 2397.18, 2370.61, 2397.94], ['21 February, 2025', 2378.82, 2325.95, 2309.17, 2378.82], ['22 February, 2025', 2322.94, 2314.16, 2308.76, 2330.88], ['25 February, 2025', 2320.62, 2325.82, 2315.01, 2338.78], ['26 February, 2025', 2313.74, 2293.34, 2289.89, 2340.71], ['27 February, 2025', 2297.77, 2313.22, 2292.03, 2324.63], ['28 February, 2025', 2322.32, 2365.59, 2308.92, 2366.16], ['1 March, 2025', 2364.54, 2359.51, 2330.86, 2369.65], ['4 March, 2025', 2332.08, 2273.4, 2259.25, 2333.54], ['5 March, 2025', 2274.81, 2326.31, 2270.1, 2328.14], ['6 March, 2025', 2333.61, 2347.18, 2321.6, 2351.44], ['7 March, 2025', 2340.44, 2324.29, 2304.27, 2352.02], ['8 March, 2025', 2326.42, 2318.61, 2314.59, 2333.67], ['11 March, 2025', 2314.68, 2310.59, 2296.58, 2320.96], ['12 March, 2025', 2309.16, 2286.6, 2264.83, 2333.29], ['13 March, 2025', 2282.17, 2263.97, 2253.25, 2286.33], ['14 March, 2025', 2255.77, 2270.28, 2253.31, 2276.22], ['15 March, 2025', 2269.31, 2278.4, 2250, 2312.08], ['18 March, 2025', 2267.29, 2240.02, 2239.21, 2276.05], ['19 March, 2025', 2244.26, 2257.43, 2232.02, 2261.31], ['20 March, 2025', 2257.74, 2317.37, 2257.42, 2317.86], ['21 March, 2025', 2318.21, 2324.24, 2311.6, 2330.81], ['22 March, 2025', 2321.4, 2328.28, 2314.97, 2332], ['25 March, 2025', 2334.74, 2326.72, 2319.91, 2344.89], ['26 March, 2025', 2318.58, 2297.67, 2281.12, 2319.99], ['27 March, 2025', 2299.38, 2301.26, 2289, 2323.48], ['28 March, 2025', 2273.55, 2236.3, 2232.91, 2273.55], ['29 March, 2025', 2238.49, 2236.62, 2228.81, 2246.87], ['1 April, 2025', 2229.46, 2234.4, 2227.31, 2243.95], ['2 April, 2025', 2234.9, 2227.74, 2220.44, 2253.42], ['3 April, 2025', 2232.69, 2225.29, 2217.25, 2241.34], ['8 April, 2025', 2196.24, 2211.59, 2180.67, 2212.59], ['9 April, 2025', 2215.47, 2225.77, 2215.47, 2234.73], ['10 April, 2025', 2224.93, 2226.13, 2212.56, 2233.04], ['11 April, 2025', 2236.98, 2219.55, 2217.26, 2242.48], ['12 April, 2025', 2218.09, 2206.78, 2204.44, 2226.26]];
export const getBasicCandlestickChart = () => ({
  tooltip: {
    trigger: 'axis',
    padding: [8, 15],
    backgroundColor: getColor('secondary-bg'),
    borderColor: getColor('border-color'),
    textStyle: {
      color: getColor('light-text-emphasis')
    },
    borderWidth: 1,
    transitionDuration: 0.125,
    axisPointer: {
      type: 'none'
    },
    shadowBlur: 2,
    shadowColor: 'rgba(76, 76, 92, 0.15)',
    shadowOffsetX: 0,
    shadowOffsetY: 1,
    formatter: params => {
      const list = Array.isArray(params) ? params : [params];
      const item = list[0];
      const [open, close, low, high] = item.data;
      const date = new Date(item.name);
      const formattedDate = date.toLocaleDateString('en-US', {
        day: '2-digit',
        month: 'long',
        year: 'numeric'
      });
      return `
        <strong>${formattedDate}</strong><br/>
        Open: ${open}<br/>
        Close: ${close}<br/>
        Low: ${low}<br/>
        High: ${high}
      `;
    }
  },
  toolbox: {
    show: false
  },
  dataZoom: [{
    type: 'inside',
    start: 0,
    end: 100,
    minValueSpan: 10
  }],
  xAxis: {
    type: 'category',
    data: data.map(d => new Date(d[0]).toISOString()),
    splitLine: {
      show: false
    },
    min: 'dataMin',
    max: 'dataMax',
    boundaryGap: true,
    axisPointer: {
      lineStyle: {
        color: getColor('tertiary-bg'),
        type: 'dashed'
      }
    },
    axisLine: {
      lineStyle: {
        color: getColor('tertiary-bg'),
        type: 'solid'
      }
    },
    axisTick: {
      show: false
    },
    axisLabel: {
      color: getColor('body-color'),
      formatter: val => new Date(val).toLocaleDateString('en-US', {
        month: 'short',
        day: '2-digit'
      }),
      margin: 15,
      fontWeight: 500
    }
  },
  yAxis: {
    min: 2150,
    axisPointer: {
      show: false
    },
    splitLine: {
      lineStyle: {
        color: getColor('border-color'),
        type: 'dashed'
      }
    },
    boundaryGap: false,
    axisLabel: {
      show: true,
      color: getColor('body-color'),
      margin: 15,
      fontWeight: 500
    },
    axisTick: {
      show: false
    },
    axisLine: {
      show: false
    }
  },
  textStyle: {
    fontFamily: getComputedStyle(document.body).fontFamily
  },
  series: [{
    type: 'candlestick',
    name: 'Volume',
    data: data.map(d => d.slice(1)),
    itemStyle: {
      color: getColor('chart-gamma'),
      color0: getColor('chart-primary'),
      borderColor: getColor('chart-gamma'),
      borderColor0: getColor('chart-primary')
    }
  }],
  grid: {
    right: 5,
    left: 5,
    bottom: 5,
    top: 10,
    containLabel: true
  }
});

// candlestick mixed chart

function splitData(rawData) {
  const categoryData = [];
  const values = [];
  for (let i = 0; i < rawData.length; i++) {
    const [date, ...rest] = rawData[i];
    categoryData.push(date);
    values.push(rest);
  }
  return {
    categoryData,
    values
  };
}
const mixedData = splitData([['2025/1/24', 2320.26, 2320.26, 2287.3, 2362.94], ['2025/1/25', 2300, 2291.3, 2288.26, 2308.38], ['2025/1/28', 2295.35, 2346.5, 2295.35, 2346.92], ['2025/1/29', 2347.22, 2358.98, 2337.35, 2363.8], ['2025/1/30', 2360.75, 2382.48, 2347.89, 2383.76], ['2025/1/31', 2383.43, 2385.42, 2371.23, 2391.82], ['2025/2/1', 2377.41, 2419.02, 2369.57, 2421.15], ['2025/2/4', 2425.92, 2428.15, 2417.58, 2440.38], ['2025/2/5', 2411, 2433.13, 2403.3, 2437.42], ['2025/2/6', 2432.68, 2434.48, 2427.7, 2441.73], ['2025/2/7', 2430.69, 2418.53, 2394.22, 2433.89], ['2025/2/8', 2416.62, 2432.4, 2414.4, 2443.03], ['2025/2/18', 2441.91, 2421.56, 2415.43, 2444.8], ['2025/2/19', 2420.26, 2382.91, 2373.53, 2427.07], ['2025/2/20', 2383.49, 2397.18, 2370.61, 2397.94], ['2025/2/21', 2378.82, 2325.95, 2309.17, 2378.82], ['2025/2/22', 2322.94, 2314.16, 2308.76, 2330.88], ['2025/2/25', 2320.62, 2325.82, 2315.01, 2338.78], ['2025/2/26', 2313.74, 2293.34, 2289.89, 2340.71], ['2025/2/27', 2297.77, 2313.22, 2292.03, 2324.63], ['2025/2/28', 2322.32, 2365.59, 2308.92, 2366.16], ['2025/3/1', 2364.54, 2359.51, 2330.86, 2369.65], ['2025/3/4', 2332.08, 2273.4, 2259.25, 2333.54], ['2025/3/5', 2274.81, 2326.31, 2270.1, 2328.14], ['2025/3/6', 2333.61, 2347.18, 2321.6, 2351.44], ['2025/3/7', 2340.44, 2324.29, 2304.27, 2352.02], ['2025/3/8', 2326.42, 2318.61, 2314.59, 2333.67], ['2025/3/11', 2314.68, 2310.59, 2296.58, 2320.96], ['2025/3/12', 2309.16, 2286.6, 2264.83, 2333.29], ['2025/3/13', 2282.17, 2263.97, 2253.25, 2286.33], ['2025/3/14', 2255.77, 2270.28, 2253.31, 2276.22], ['2025/3/15', 2269.31, 2278.4, 2250, 2312.08], ['2025/3/18', 2267.29, 2240.02, 2239.21, 2276.05], ['2025/3/19', 2244.26, 2257.43, 2232.02, 2261.31], ['2025/3/20', 2257.74, 2317.37, 2257.42, 2317.86], ['2025/3/21', 2318.21, 2324.24, 2311.6, 2330.81], ['2025/3/22', 2321.4, 2328.28, 2314.97, 2332], ['2025/3/25', 2334.74, 2326.72, 2319.91, 2344.89], ['2025/3/26', 2318.58, 2297.67, 2281.12, 2319.99], ['2025/3/27', 2299.38, 2301.26, 2289, 2323.48], ['2025/3/28', 2273.55, 2236.3, 2232.91, 2273.55], ['2025/3/29', 2238.49, 2236.62, 2228.81, 2246.87], ['2025/4/1', 2229.46, 2234.4, 2227.31, 2243.95], ['2025/4/2', 2234.9, 2227.74, 2220.44, 2253.42], ['2025/4/3', 2232.69, 2225.29, 2217.25, 2241.34], ['2025/4/8', 2196.24, 2211.59, 2180.67, 2212.59], ['2025/4/9', 2215.47, 2225.77, 2215.47, 2234.73], ['2025/4/10', 2224.93, 2226.13, 2212.56, 2233.04], ['2025/4/11', 2236.98, 2219.55, 2217.26, 2242.48], ['2025/4/12', 2218.09, 2206.78, 2204.44, 2226.26], ['2025/4/15', 2199.91, 2181.94, 2177.39, 2204.99], ['2025/4/16', 2169.63, 2194.85, 2165.78, 2196.43], ['2025/4/17', 2195.03, 2193.8, 2178.47, 2197.51], ['2025/4/18', 2181.82, 2197.6, 2175.44, 2206.03], ['2025/4/19', 2201.12, 2244.64, 2200.58, 2250.11], ['2025/4/22', 2236.4, 2242.17, 2232.26, 2245.12], ['2025/4/23', 2242.62, 2184.54, 2182.81, 2242.62], ['2025/4/24', 2187.35, 2218.32, 2184.11, 2226.12], ['2025/4/25', 2213.19, 2199.31, 2191.85, 2224.63], ['2025/4/26', 2203.89, 2177.91, 2173.86, 2210.58], ['2025/5/2', 2170.78, 2174.12, 2161.14, 2179.65], ['2025/5/3', 2179.05, 2205.5, 2179.05, 2222.81], ['2025/5/6', 2212.5, 2231.17, 2212.5, 2236.07], ['2025/5/7', 2227.86, 2235.57, 2219.44, 2240.26], ['2025/5/8', 2242.39, 2246.3, 2235.42, 2255.21], ['2025/5/9', 2246.96, 2232.97, 2221.38, 2247.86], ['2025/5/10', 2228.82, 2246.83, 2225.81, 2247.67], ['2025/5/13', 2247.68, 2241.92, 2231.36, 2250.85], ['2025/5/14', 2238.9, 2217.01, 2205.87, 2239.93], ['2025/5/15', 2217.09, 2224.8, 2213.58, 2225.19], ['2025/5/16', 2221.34, 2251.81, 2210.77, 2252.87], ['2025/5/17', 2249.81, 2282.87, 2248.41, 2288.09], ['2025/5/20', 2286.33, 2299.99, 2281.9, 2309.39], ['2025/5/21', 2297.11, 2305.11, 2290.12, 2305.3], ['2025/5/22', 2303.75, 2302.4, 2292.43, 2314.18], ['2025/5/23', 2293.81, 2275.67, 2274.1, 2304.95], ['2025/5/24', 2281.45, 2288.53, 2270.25, 2292.59], ['2025/5/27', 2286.66, 2293.08, 2283.94, 2301.7], ['2025/5/28', 2293.4, 2321.32, 2281.47, 2322.1], ['2025/5/29', 2323.54, 2324.02, 2321.17, 2334.33], ['2025/5/30', 2316.25, 2317.75, 2310.49, 2325.72], ['2025/5/31', 2320.74, 2300.59, 2299.37, 2325.53], ['2025/6/3', 2300.21, 2299.25, 2294.11, 2313.43], ['2025/6/4', 2297.1, 2272.42, 2264.76, 2297.1], ['2025/6/5', 2270.71, 2270.93, 2260.87, 2276.86], ['2025/6/6', 2264.43, 2242.11, 2240.07, 2266.69], ['2025/6/7', 2242.26, 2210.9, 2205.07, 2250.63], ['2025/6/13', 2190.1, 2148.35, 2126.22, 2190.1]]);
function calculateMA(dayCount) {
  const result = [];
  for (let i = 0, len = mixedData.values.length; i < len; i++) {
    if (i < dayCount) {
      result.push('-');
      continue;
    }
    let sum = 0;
    for (let j = 0; j < dayCount; j++) {
      sum += mixedData.values[i - j][1]; // use closing price
    }
    result.push(sum / dayCount);
  }
  return result;
}
export const getMixedCandlestickChart = () => ({
  backgroundColor: 'transparent',
  tooltip: {
    trigger: 'axis',
    padding: [8, 15],
    backgroundColor: getColor('secondary-bg'),
    borderColor: getColor('border-color'),
    textStyle: {
      color: getColor('light-text-emphasis')
    },
    borderWidth: 1,
    transitionDuration: 0.125,
    shadowBlur: 2,
    shadowColor: 'rgba(76, 76, 92, 0.15)',
    shadowOffsetX: 0,
    shadowOffsetY: 1,
    axisPointer: {
      type: 'cross'
    }
  },
  legend: {
    data: ['INS', 'MA5', 'MA10', 'MA20', 'MA30'],
    textStyle: {
      color: getColor('body-color')
    }
  },
  grid: {
    left: '5%',
    right: '5%',
    bottom: '20%',
    top: '10%'
  },
  textStyle: {
    fontFamily: getComputedStyle(document.body).fontFamily
  },
  xAxis: {
    type: 'category',
    data: mixedData.categoryData,
    boundaryGap: false,
    splitLine: {
      show: false
    },
    min: 'dataMin',
    max: 'dataMax',
    axisLine: {
      onZero: false,
      lineStyle: {
        type: 'dashed',
        color: getColor('light')
      }
    },
    axisLabel: {
      show: true,
      color: getColor('body-color')
    }
  },
  yAxis: {
    scale: true,
    splitArea: {
      show: false
    },
    axisLine: {
      lineStyle: {
        type: 'dashed',
        color: getColor('light')
      }
    },
    axisLabel: {
      show: true,
      color: getColor('body-color')
    },
    splitLine: {
      lineStyle: {
        color: 'rgba(133, 141, 152, 0.1)',
        type: 'dashed'
      }
    }
  },
  dataZoom: [{
    type: 'inside',
    start: 50,
    end: 100
  }, {
    show: true,
    type: 'slider',
    top: '90%',
    start: 50,
    end: 100,
    backgroundColor: 'rgba(0, 0, 0, 0)',
    borderColor: getColor('border-color'),
    fillerColor: getColor('chart-primary-rgb', 0.25),
    dataBackground: {
      lineStyle: {
        color: getColor('chart-primary')
      },
      areaStyle: {
        color: 'rgba(255, 255, 255, 0.05)'
      }
    },
    handleIcon: 'M10,0 L0,10 L10,20 L20,10 Z',
    handleSize: '100%',
    handleStyle: {
      color: getColor('chart-primary'),
      borderColor: getColor('border-color')
    },
    textStyle: {
      color: getColor('body-color')
    },
    labelFormatter: value => `Day ${value}`
  }],
  series: [{
    name: 'INS',
    type: 'candlestick',
    data: mixedData.values,
    itemStyle: {
      color: getColor('chart-primary'),
      color0: getColor('chart-beta'),
      borderColor: getColor('chart-primary'),
      borderColor0: getColor('chart-beta')
    },
    markPoint: {
      label: {
        formatter: function (param) {
          const p = param;
          if (!p) return '';
          const raw = p.value;
          const num = Array.isArray(raw) && raw.length > 1 ? Number(raw[1]) : typeof raw === 'number' ? raw : Number(raw);
          return Number.isFinite(num) ? Math.round(num).toString() : '';
        },
        color: '#fff',
        fontWeight: 700,
        fontSize: 10
      },
      data: [{
        name: 'Mark',
        coord: ['2025/5/31', 2300],
        value: 2300,
        itemStyle: {
          color: 'rgb(41,60,85)'
        }
      }, {
        name: 'highest value',
        type: 'max',
        valueDim: 'highest'
      }, {
        name: 'lowest value',
        type: 'min',
        valueDim: 'lowest'
      }, {
        name: 'average value on close',
        type: 'average',
        valueDim: 'close'
      }],
      tooltip: {
        formatter: function (params) {
          const param = Array.isArray(params) ? params[0] : params;
          if (!param) return '';
          let coordStr = '';
          if (param.data && typeof param.data === 'object' && 'coord' in param.data) {
            coordStr = Array.isArray(param.data.coord) ? param.data.coord.join(', ') : String(param.data.coord);
          }
          return param.name + '<br>' + coordStr;
        }
      }
    },
    markLine: {
      symbol: ['none', 'none'],
      data: [[{
        name: 'from lowest to highest',
        type: 'min',
        valueDim: 'lowest',
        symbol: 'circle',
        symbolSize: 10,
        label: {
          show: false
        },
        emphasis: {
          label: {
            show: false
          }
        }
      }, {
        type: 'max',
        valueDim: 'highest',
        symbol: 'circle',
        symbolSize: 10,
        label: {
          show: false
        },
        emphasis: {
          label: {
            show: false
          }
        }
      }], {
        name: 'min line on close',
        type: 'min',
        valueDim: 'close'
      }, {
        name: 'max line on close',
        type: 'max',
        valueDim: 'close'
      }]
    }
  },
  // MA lines — cast to the explicit line series option type
  {
    name: 'MA5',
    type: 'line',
    smooth: true,
    data: calculateMA(5),
    itemStyle: {
      color: getColor('chart-zeta')
    },
    lineStyle: {
      opacity: 0.9
    }
  }, {
    name: 'MA10',
    type: 'line',
    smooth: true,
    data: calculateMA(10),
    itemStyle: {
      color: getColor('chart-secondary')
    },
    lineStyle: {
      opacity: 0.5
    }
  }, {
    name: 'MA20',
    type: 'line',
    smooth: true,
    data: calculateMA(20),
    itemStyle: {
      color: getColor('chart-gamma')
    },
    lineStyle: {
      opacity: 0.5
    }
  }, {
    name: 'MA30',
    type: 'line',
    smooth: true,
    data: calculateMA(30),
    itemStyle: {
      color: getColor('chart-beta')
    },
    lineStyle: {
      opacity: 0.5
    }
  }]
});