import { Link } from 'react-router';
import { META_DATA } from '@/config/constants';
import PageMetaData from './PageMetaData';
const PageBreadcrumb = ({
  title,
  subtitle
}) => {
  return <>
            <PageMetaData title={title} />
            <div className='page-title-head d-flex align-items-center'>
                <div className='flex-grow-1'>
                    <h4 className='fs-sm text-uppercase fw-bold m-0'>{title}</h4>
                </div>
                <div className='text-end'>
                    <ol className='breadcrumb m-0 py-0'>
                        <li className='breadcrumb-item'>
                            <Link to="">
                                {META_DATA.name}
                            </Link>
                        </li>
                        {subtitle && <li className='breadcrumb-item'>
                            <Link to="">
                                {subtitle}
                            </Link>
                            </li>}
                        <Link className='breadcrumb-item active' to=''>
                            {title}
                        </Link>
                    </ol>
                </div>
            </div>
        </>;
};
export default PageBreadcrumb;