<?php

namespace App\Http\Controllers\PublicApi;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class CaseStudyController extends Controller
{
    /**
     * GET /api/case-studies
     *
     * Paginated list of active case studies, similar to the old CMS.
     */
    public function index(Request $request)
    {
        $table = 'case_studies';
        $groupsTable = 'case_study_groups';

        if (! Schema::hasTable($table)) {
            return response()->json([
                'message' => "Table [{$table}] does not exist. Please ensure your imported table name is '{$table}'.",
            ], 500);
        }

        // Base query from main table
        $query = DB::table($table);

        // If we have a separate groups table, join it and expose "group_name" and "group_description"
        $selects = [];

        // Core case_studies columns (only add if they actually exist)
        $candidateColumns = [
            'id',
            'title',
            'slug',
            'category',
            'featured_image',
            'project_link',
            'client_name',
            'description',
            'tags',
            'status',
            'group_name',
            'group_description',
            'created_at',
            'updated_at',
        ];

        foreach ($candidateColumns as $col) {
            // group_name / group_description may come from a related table; handle below
            if (in_array($col, ['group_name', 'group_description'], true)) {
                continue;
            }

            if (Schema::hasColumn($table, $col)) {
                $selects[] = $table . '.' . $col;
            }
        }

        // Optional join for group metadata when normalized into a second table
        if (
            Schema::hasTable($groupsTable)
            && Schema::hasColumn($table, 'group_id')
            && Schema::hasColumn($groupsTable, 'id')
        ) {
            $query->leftJoin($groupsTable, $groupsTable . '.id', '=', $table . '.group_id');

            if (Schema::hasColumn($groupsTable, 'name')) {
                $selects[] = $groupsTable . '.name as group_name';
            }
            if (Schema::hasColumn($groupsTable, 'description')) {
                $selects[] = $groupsTable . '.description as group_description';
            }
        } else {
            // If group_* are denormalized columns directly on case_studies, include them directly
            foreach (['group_name', 'group_description'] as $col) {
                if (Schema::hasColumn($table, $col)) {
                    $selects[] = $table . '.' . $col;
                }
            }
        }

        if (! empty($selects)) {
            $query->select($selects);
        }

        // Common "active" flags if present
        if (Schema::hasColumn($table, 'is_active')) {
            $query->where('is_active', 1);
        } elseif (Schema::hasColumn($table, 'status')) {
            $query->where('status', 'published');
        }

        // Optional search by title/category/client
        $search = $request->string('search')->toString();
        if ($search !== '') {
            $query->where(function ($q) use ($search, $table) {
                foreach (['title', 'category', 'client_name'] as $col) {
                    if (Schema::hasColumn($table, $col)) {
                        $q->orWhere($col, 'like', '%' . $search . '%');
                    }
                }
            });
        }

        $perPage = (int) $request->input('per_page', 12);

        $paginator = $query->paginate($perPage);

        // Decode tags JSON if needed so API matches expected structure
        $paginator->getCollection()->transform(function ($item) {
            if (property_exists($item, 'tags') && is_string($item->tags)) {
                $decoded = json_decode($item->tags, true);
                if (json_last_error() === JSON_ERROR_NONE) {
                    $item->tags = $decoded;
                }
            }
            return $item;
        });

        return response()->json($paginator);
    }

    /**
     * GET /api/case-studies/{slug}
     *
     * Single case study detail + its dynamic sections.
     * Assumes a related table like "case_study_sections" with a case_study_id FK.
     */
    public function show(string $slug)
    {
        $table = 'case_studies';
        $groupsTable = 'case_study_groups';

        if (! Schema::hasTable($table)) {
            return response()->json([
                'message' => "Table [{$table}] does not exist. Please ensure your imported table name is '{$table}'.",
            ], 500);
        }

        // Base query for single case study (with optional group join)
        $query = DB::table($table);

        $selects = [$table . '.*'];

        if (
            Schema::hasTable($groupsTable)
            && Schema::hasColumn($table, 'group_id')
            && Schema::hasColumn($groupsTable, 'id')
        ) {
            $query->leftJoin($groupsTable, $groupsTable . '.id', '=', $table . '.group_id');

            if (Schema::hasColumn($groupsTable, 'name')) {
                $selects[] = $groupsTable . '.name as group_name';
            }
            if (Schema::hasColumn($groupsTable, 'description')) {
                $selects[] = $groupsTable . '.description as group_description';
            }
        }

        $caseStudy = $query
            ->select($selects)
            ->where($table . '.slug', $slug)
            ->first();

        if (! $caseStudy) {
            return response()->json(['message' => 'Case study not found.'], 404);
        }

        // Attach dynamic sections if a sections table exists
        $sectionsTable = 'case_study_sections';
        $sections = [];

        if (Schema::hasTable($sectionsTable)) {
            $sectionsQuery = DB::table($sectionsTable);

            if (Schema::hasColumn($sectionsTable, 'case_study_id')) {
                $sectionsQuery->where('case_study_id', $caseStudy->id);
            }

            if (Schema::hasColumn($sectionsTable, 'sort_order')) {
                $sectionsQuery->orderBy('sort_order');
            }

            $sections = $sectionsQuery->get()->map(function ($row) {
                // If there's a JSON "content" column, decode it
                if (property_exists($row, 'content') && is_string($row->content)) {
                    $decoded = json_decode($row->content, true);
                    if (json_last_error() === JSON_ERROR_NONE) {
                        $row->content = $decoded;
                    }
                }

                return $row;
            })->values()->all();
        }

        // Convert stdClass to array and attach sections, matching old API style
        $data = (array) $caseStudy;
        // Decode tags JSON for detail endpoint as well
        if (array_key_exists('tags', $data) && is_string($data['tags'])) {
            $decoded = json_decode($data['tags'], true);
            if (json_last_error() === JSON_ERROR_NONE) {
                $data['tags'] = $decoded;
            }
        }
        $data['sections'] = $sections;

        return response()->json(['data' => $data]);
    }
}

